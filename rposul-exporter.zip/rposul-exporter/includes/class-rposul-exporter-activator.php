<?php

/**
 * Fired during plugin activation
 *
 * @link       http://example.com
 * @since      0.1.0
 *
 * @package    Rposul_Exporter
 * @subpackage Rposul_Exporter/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      0.1.0
 * @package    Rposul_Exporter
 * @subpackage Rposul_Exporter/includes
 * @author     Your Name <email@example.com>
 */
class Rposul_Exporter_Activator
{

    /**
     * Short Description. (use period)
     *
     * Long Description.
     *
     * @since    0.1.0
     */
    public static function activate()
    {
        self::install_db();
    }

    public static function install_db()
    {
        global $wpdb;

        $db_version = "3.3.0";
        $installed_ver = get_option("rposul_db_version");

        if (version_compare($installed_ver, $db_version, "!=")) {
            require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

            $charset_collate = $wpdb->get_charset_collate();

            $table_name = $wpdb->prefix . "rposul_options";

            $sql = "CREATE TABLE $table_name (
		  id MEDIUMINT(9) NOT NULL AUTO_INCREMENT,
		  option_name VARCHAR(50) NULL,
		  option_value LONGTEXT NOT NULL,                  
		  UNIQUE KEY id (id)
		) $charset_collate;";
            dbDelta($sql);

            Rposul_Page::create_table($installed_ver);            
            Rposul_Insertion::create_table($installed_ver);
            Rposul_Advertisement::create_table($installed_ver);
            Rposul_Header::create_table($installed_ver);

            if (version_compare($installed_ver, "3.3.1", "<")) {
                // This table is no longer required
                //$wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}rposul_columnists");
            }

            update_option("rposul_db_version", $db_version);
        }
    }
}
