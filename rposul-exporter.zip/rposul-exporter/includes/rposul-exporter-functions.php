<?php

function is_rposul_page() {
    $screen = get_current_screen();
    $pages = array(
        'toplevel_page_' . Rposul_Exporter_Admin_Page_Main::MENU_SLUG,
        'exportador-pdf_page_' . Rposul_Exporter_Admin_Page_Manage_Ads::MENU_SLUG,
        'admin_page_' . Rposul_Exporter_Admin_Page_Edit_Ads::MENU_SLUG,        
        'exportador-pdf_page_' . Rposul_Exporter_Admin_Page_Manage_Insertions::MENU_SLUG
    );
    return (in_array($screen->id, $pages));
}

/**
 * Merge multiple WP_Error objects together
 *
 * @return WP_Error | boolean Boolean True in case of none of the parameters 
 * are WP_Error objects.
 */
function rposul_wp_error_merge() {
    $wp_error_merged = new WP_Error();
    $wp_errors = func_get_args();
    foreach ($wp_errors as $wp_error) {
        if (!is_wp_error($wp_error)) {
            continue;
        }
        /**
         * @var WP_Error $wp_error
         */
        $error_codes = $wp_error->get_error_codes();
        foreach ($error_codes as $error_code) {
            // Merge error messages
            $error_messages = $wp_error->get_error_messages($error_code);
            foreach ($error_messages as $error_message) {
                $wp_error_merged->add($error_code, $error_message);
            }
            // Merge error data
            $error_data = $wp_error->get_error_data($error_code);
            if ($error_data) {
                $prev_error_data = $wp_error_merged->get_error_data($error_code);
                if (!empty($prev_error_data) && is_array($error_data) && is_array($prev_error_data)) {
                    $wp_error_merged->add_data(array_merge($prev_error_data, $error_data), $error_code);
                } else {
                    $wp_error_merged->add_data($error_data, $error_code);
                }
            }
        }
    }
    return $wp_error_merged->get_error_codes() ? $wp_error_merged : true;
}

function rposul_ensure_ends_with_dot($haystack) {
    $needle = ".";
    $length = strlen($needle);
    if ($length == 0) {
        return $haystack;
    }

    if (substr($haystack, -$length) === $needle) {
        return $haystack;
    } else {
        return $haystack . $needle;
    }
}

function rposul_get_posts_li($args = array()) {
    $args['fields'] = "all";
    $parsed_args = wp_parse_args($args, array(
        'disable_pageposts' => true,
        'trash' => false,
    ));

    $posts_retrieved = rposul_get_posts($parsed_args);
    if ($parsed_args['disable_pageposts']) {
        $pageposts = Rposul_Page::find_pageposts();
    }

    $trash_html = '<button class="fa fa-trash ui-sortable-trash" aria-hidden="true"></button>';

    $html = "";
    foreach ($posts_retrieved as $post) {
        if (!isset($post->ID)) {
            $post_stub = new stdClass();
            $post_stub->ID = $post;
            $post_stub->post_title = "Post inexistente (Apagado?)";
            $post_stub->post_content_length = '';
            $post_stub->error = true;
            $post = $post_stub;
            $state_classes = 'ui-state-error ';
        } else {
            $state_classes = "ui-state-default ";
        }

        $state_classes .= $post->published_date ? 'ui-state-published ' : '';

        if ($parsed_args['disable_pageposts']) {
            foreach ($pageposts as $pagepost) {
                if ($pagepost['post_id'] == $post->ID) {
                    $state_classes .= 'ui-state-disabled ';
                    break;
                }
            }
        }
        $post_permalink = get_permalink($post->ID);
        $view_html = "<a class='ui-sortable-view' target='_blank' href='$post_permalink'><i class='dashicons dashicons-visibility'></i></a>";
        $category_names = empty($post->error) ? get_the_category_list(", ", '', $post->ID) : '';

        $html .= "<li class='sortable-post $state_classes' "
                . "data-postid='$post->ID' "
                . "data-size='$post->post_content_length'"
                . "data-date='$post->post_date'"
                . ">"
                . "$trash_html"
                . "$view_html"
                . "<span class='post-title'>$post->post_title</span>"
                . "<span class='post-categories'>$category_names</span>"
                . "<span class='post-content-length'>Tamanho: $post->post_content_length</span>"
//                . "<span class='published-date'>Publicado em: $post->published_date</span>"
                . "</li>";
    }

    return $html;
}

function rposul_get_advertisements_li($args = array()) {
    $pageads = Rposul_Page::find_pageads(array("WHERE" => "page_id={$args['page_id']}"));
    $trash_html = '<button class="fa fa-trash ui-sortable-trash" aria-hidden="true"></button>';
    $html = "";
    foreach ($pageads as $ad) {
        $advertisements = Rposul_Advertisement::get(array('WHERE' => "id={$ad['advertisement_id']}"));
        $advertisement = $advertisements[0];
        /* @var $advertisement Rposul_Advertisement */
        $advertisement_type = $advertisement->type == 'full' ? "(Página Inteira)" : '(Parcial)';
        $html .= "<li class='ui-state-default sortable-advertisement' data-adid='{$advertisement->get_id()}'>"
                . "$trash_html"
                . "<span class='post-title'>$advertisement->title $advertisement_type</span>"
                . "</li>";
    }

    return $html;
}

function rposul_get_extras_li($args = array()) {
    $page = $args['page'];
    $trash_html = '<button class="fa fa-trash ui-sortable-trash" aria-hidden="true"></button>';
    $insertion_id = arr_get($page->extra_values, 'insertion_id');
    $html = "";
    if ($insertion_id) {
        $insertions = Rposul_Insertion::get(array('WHERE' => "id=$insertion_id"));
        $insertion = $insertions[0];
        $html .= "<li class='ui-state-default sortable-insertion' data-insertionid='{$insertion_id}'>"
                . "$trash_html"
                . "<span class='post-title'>$insertion->name</span>"
                . "</li>";
    }

    return $html;
}

/**
 * The year of the newspaper. Check issue #1096
 * @param str $date Date to check the year YYYY-MM-DD
 */
function rposul_get_newspaper_year_from_date($date) {
    $news_datetime = new DateTime($date);
    $reference_datetime = new DateTime('2001-07-02');	
    $difference = $reference_datetime->diff($news_datetime);
    $ret_val = $difference->y + 1;
    return !$difference->invert ? $ret_val : 0;
}

function rposul_get_news_number_from_date($date) {

    $reference_datetime = new DateTime('2017-03-07');
    $news_datetime = new DateTime($date);
    $difference = $reference_datetime->diff($news_datetime);

    $day = intval($news_datetime->format("j"));
    $month = intval($news_datetime->format("n"));

    $adjust = 0;

    //Christmas double date newspaper
    if ($difference->invert) {
        if ($month < 12 || $day <= 24) {
            $adjust += $reference_datetime->format("Y") - $news_datetime->format("Y");
        }
    } else {
        $adjust += $reference_datetime->format("Y") - $news_datetime->format("Y");
        if ($month == 12 && $day >= 25) {
            // will be a negative number
            $adjust += -1;
        }
    }

    //New years eve double date newspaper
    if ($difference->invert) {
        $adjust += $reference_datetime->format("Y") - $news_datetime->format("Y");
    } else {
        // will be a negative number
        $adjust += $reference_datetime->format("Y") - $news_datetime->format("Y");
    }


    $difference_days = intval($difference->format("%r%a"));
    $difference_days += $adjust;

    //5662 was the number of the edition in 7 march 2017. We count from that date
    $newspaper_number = 5662 + $difference_days;

    return $newspaper_number;
}

function rposul_retrieve_adv_image_url($ad_obj) {
    /* @var $ad_obj Rposul_Advertisement */
    $attachment_info = rposul_get_attachment($ad_obj->image_id);
    return !empty($attachment_info) ? $attachment_info['url'] : null;
}

function rposul_retrieve_post_content_length($pid, $forcecalc = false) {
    if (!$forcecalc) {
        $postlen = get_post_meta($pid, RPOSUL_CONTENT_LENGTH_POST_META, true);
    } else {
        $postlen = NULL;
    }
    if (!$postlen) {
        $decoded_text = rposul_html_decode(get_post($pid)->post_content);
        $new_lines_count = mb_substr_count($decoded_text, "\n");
        $calculatedleng = mb_strlen($decoded_text);
        if ($new_lines_count > 50) {
            $calculatedleng += $new_lines_count * 10;
        }

        return $calculatedleng;
    } else {
        return $postlen;
    }
}

function rposul_get_attachment($attachment_id) {
    if (!$attachment_id) {
        return null;
    }
    $attachment = get_post($attachment_id);
    $attachment_meta = wp_get_attachment_metadata($attachment->ID);

    if (strtolower(substr($attachment_meta['file'], -4)) === ".gif") {
        return null;
    }

    $matches = null;
    // Maybe does not get all sources because they must be between ()
    $has_matches = preg_match(
            '/^(.*)\s*[(]\s*(Foto|Crédito|Credito)[s]?:\s*(.*?)[)]\s*$/im', $attachment->post_excerpt, $matches);
    if ($has_matches) {
        $real_image_author = $matches[3];
        $caption = $matches[1];
    } else {
        $real_image_author = '';
        $caption = $attachment->post_excerpt;
    }

    $return_info = array(
        'alt' => get_post_meta($attachment->ID, '_wp_attachment_image_alt', true),
        'height' => $attachment_meta['height'],
        'width' => $attachment_meta['width'],
        'aspect_ratio' => !empty($attachment_meta['height']) ? $attachment_meta['width'] / $attachment_meta['height'] : 0,
        'caption' => $caption,
        'credit_to' => $real_image_author,
        'description' => $attachment->post_content,
        'href' => get_permalink($attachment->ID),
        'title' => $attachment->post_title,
        'url' => str_replace('dev.wordpress', 'www.osul.com.br', wp_get_attachment_url($attachment->ID))
    );

    return $return_info;
}

function rposul_compare_date($date1, $date2) {
    if ($date1->format('y-m-d') == $date2->format('y-m-d')) {
        return 0;
    } elseif ($date1 > $date2) {
        return 1;
    } else {
        return -1;
    }
}

/**
 * A utility function intended for removing duplicate DateTime objects from array
 *
 * @param array $array Array of DateTime objects (though can work for other objects)
 * @return array A sub-array of the passed array, containing only unique elements.
 */
function remove_duplicates_datetime($array = array()) {
    //Do we need to worry about the times of the date-time objects?

    if (empty($array))
        return $array;

    $unique = array();
    foreach ($array as $key => $object) {
        if (!in_array($object, $unique))
            $unique[$key] = $object;
    }

    return $unique;
}

/**
 * Gets the nth occurrence of a weekday in its month
 * 
 * @param type $datetime
 * @return int Return the number of the occurrence or -1 if it is the last occurence
 */
function get_weekday_occurrence_for_month($datetime) {
    $monthstart = clone $datetime;
    $monthend = clone $datetime;
    $monthstart->modify('first day of this month');
    $monthend->modify('last day of this month');

    $monthstartts = $monthstart->getTimestamp();
    $monthendts = $monthend->getTimestamp();

    $occurrences = array();
    $starttime = strtotime($datetime->format('l'), $monthstartts);
    for ($i = $starttime; $i <= $monthendts; $i = strtotime('+1 week', $i)) {
        $dt = new DateTime();
        $occurrences[] = $dt->setTimestamp($i);
    }

    $index = 0;
    foreach ($occurrences as $value) {
        if ($value->format('y-m-d') == $datetime->format('y-m-d')) {
            break;
        }
        $index++;
    }

    if (($index + 1) == count($occurrences)) {
        return -1;
    } else {
        return $index;
    }
}

/**
 * returns a list os valid posts types considered in the rposul_exporter plugin
 * @return array
 */
function rposul_valid_post_status() {
    return array('publish', 'private', 'future');
}

/**
 * Plugin version of the get_posts method. This execute a query following 
 * different parameters to get_posts to create the newspaper
 * 
 * @global type $wpdb
 * @param array $args options arguments
 * @return array array of post results
 */
function rposul_get_posts($args = array()) {

    $parsed_args = wp_parse_args($args, array(
        'date' => null, 'until_date' => null,
        "fields" => 'ids', 'include_published_date_field' => true,
        'exclude_published' => false, 'post__in' => null,
        'orderby' => null, 'order' => 'DESC'
    ));

    //Fallback to get only posts from the configured date if nothing else is set
    if ($parsed_args['date'] === null && $parsed_args['post__in'] === null) {
        $parsed_args['date'] = DateTime::createFromFormat(RPOSUL_DATE_FORMAT, RPOSUL_Options::get_option(RPOSUL_OPTION_NEWSPAPER_DATE));
        if (!$parsed_args['date']) {
            $parsed_args['date'] = new DateTime();
        }
    }

    global $wpdb;

    $only_ids = $parsed_args['fields'] === 'ids';

    $querystr = "";
    if ($only_ids) {
        $querystr .= "SELECT p.ID ";
    } else {
        $querystr .= "SELECT p.*, IFNULL(pm.meta_value, LENGTH(p.post_content)) as post_content_length ";
    }

    $querystr .= "FROM $wpdb->posts as p "
            . "LEFT JOIN $wpdb->postmeta as pm "
            . "ON p.ID = pm.post_id AND pm.meta_key = '" . RPOSUL_CONTENT_LENGTH_POST_META . "' WHERE 1=1";

    $querystr .= " AND (p.post_status = 'publish' OR p.post_status = 'private' OR p.post_status = 'future') AND p.post_type = 'post'";

    if ($parsed_args['date']) {
        $parsed_args['date'] = clone $parsed_args['date'];

        if (!$parsed_args['until_date']) {
            $parsed_args['until_date'] = clone $parsed_args['date'];
        } else {
            $parsed_args['until_date'] = clone $parsed_args['until_date'];
        }

        $parsed_args['until_date']->modify("+1 day");
        $date_hour = 4 + $parsed_args['date']->getOffset() / 3600;
        $until_date_hour = 4 + $parsed_args['until_date']->getOffset() / 3600;

        $querystr .= " AND p.post_date>='{$parsed_args['date']->format(RPOSUL_DATE_FORMAT)} 0$date_hour:00:00' 
    AND p.post_date<='{$parsed_args['until_date']->format(RPOSUL_DATE_FORMAT)} 0$until_date_hour:00:00'";
    }

    if ($parsed_args['post__in']) {
        $post__in = implode(',', array_map('absint', $parsed_args['post__in']));
        $querystr .= " AND p.ID IN ($post__in)";
    }

    $querystr .= " GROUP BY p.ID ";

    $create_subquery = $parsed_args['include_published_date_field'] || $parsed_args['exclude_published'];

    if ($create_subquery) {
        $querystr = "SELECT derived.*, pm.meta_value as published_date FROM ($querystr) as derived 
            LEFT JOIN $wpdb->postmeta as pm ON derived.ID = pm.post_id AND (pm.meta_key = '" . RPOSUL_PUBLISHED_DATE_POST_META . "') ";

        if ($parsed_args['exclude_published']) {
            $querystr .= "WHERE pm.meta_value IS NOT NULL GROUP BY ID ";
        }

        $querystr .= "GROUP BY ID";
    }

    if ($parsed_args['orderby']) {
        $querystr .= " ORDER BY {$parsed_args['orderby']} {$parsed_args['order']} ";
    }

    if ($only_ids) {
        $posts_results = $wpdb->get_col($querystr);
    } else {
        $posts_results = $wpdb->get_results($querystr);
    }

    if ($create_subquery && $parsed_args['post__in']) {
        //Subquery may change de order of the results. We want to stick to the
        //same order as posts in
        // The reorder is done this way so we dont consume repeated postids
        $ordered_post_results = $parsed_args['post__in'];
        for ($index = 0; $index < count($ordered_post_results); $index++) {
            $pid = $ordered_post_results[$index];
            foreach ($posts_results as $value) {
                if ($value->ID == $pid) {
                    $ordered_post_results[$index] = $value;
                    break;
                }
            }
        }
        $posts_results = $ordered_post_results;
    }

    return $posts_results;
}

function rposul_get_datetime_now($normalize = false) {
    $now = DateTime::createFromFormat('U', current_time('timestamp'));
    if ($normalize) {
        $now->setTime(0, 0, 0);
    }
    return $now;
}

function rposul_get_datetime_from_mysqldatetime($string) {
    if (empty($string)) {
        return null;
    }
    return DateTime::createFromFormat('Y-m-d H:i:s', $string);
}

function rposul_get_mysqldatetime_from_datetime($datetime) {
    if (empty($datetime)) {
        return null;
    }
    return $datetime->format('Y-m-d H:i:s');
}

function rposul_get_timezone() {
    $tzstring = get_option('timezone_string');
    $offset = get_option('gmt_offset');

    //We should descourage manual offset
    //@see http://us.php.net/manual/en/timezones.others.php
    //@see https://bugs.php.net/bug.php?id=45543
    //@see https://bugs.php.net/bug.php?id=45528
    //IANA timezone database that provides PHP's timezone support uses (i.e. reversed) POSIX style signs
    if (empty($tzstring) && 0 != $offset && floor($offset) == $offset) {
        $offset_st = $offset > 0 ? "-$offset" : '+' . absint($offset);
        $tzstring = 'Etc/GMT' . $offset_st;
    }

    //Issue with the timezone selected, set to 'UTC'
    if (empty($tzstring)) {
        $tzstring = 'UTC';
    }

    if ($tzstring instanceof DateTimeZone) {
        return $tzstring;
    }

    $timezone = new DateTimeZone($tzstring);
    return $timezone;
}

function add_args_to_sql($sql, $args) {
    if (array_key_exists("SELECT", $args)) {
        $newsql = "SELECT " . $args["SELECT"];
        unset($args['SELECT']);
    } else {
        $newsql = $sql;
    }

    if (array_key_exists('WHERE', $args)) {
        $newsql .= " WHERE {$args['WHERE']}";
    }
    if (array_key_exists('ORDER BY', $args)) {
        $newsql .= " ORDER BY {$args['ORDER BY']}";
    }

    foreach ($args as $command => $parameter) {
        if ($command !== "ORDER BY" && $command !== "WHERE") {
            $newsql .= " $command $parameter";
        }
    }

    return $newsql;
}

function rposul_html_decode($input) {
    $the_mod_content = trim($input);
    $the_mod_content = str_replace('&nbsp;', " ", $the_mod_content);
    $the_mod_content = str_replace('&amp;', "&", $the_mod_content);
    $the_mod_content = str_replace('</p>', "\n", $the_mod_content);
    $a = strlen($the_mod_content);
    $the_mod_content = str_replace(array('<br>', '<br/>', "<br>", "<br />"), "\n\n", $the_mod_content);
    $the_mod_content = preg_replace("/\[caption.*?\[\/caption]/", "", $the_mod_content);
    $the_mod_content = preg_replace("/\[embed.*?\[\/embed]/", "", $the_mod_content);

    $the_mod_content = html_entity_decode($the_mod_content, ENT_QUOTES, 'UTF-8');

    //TODO isso aqui nao está correto
    $the_mod_content = preg_replace("/\[[^]]+\]/", "", $the_mod_content);
    //$the_mod_content = str_replace('"', '\'\'', $the_mod_content);        

    $the_mod_content = wp_strip_all_tags($the_mod_content, false);
    return $the_mod_content;
}

function rposul_exporter_format_atts($atts) {
    $html = '';

    $prioritized_atts = array('type', 'name', 'value');

    foreach ($prioritized_atts as $att) {
        if (isset($atts[$att])) {
            $value = trim($atts[$att]);
            $html .= sprintf(' %s="%s"', $att, esc_attr($value));
            unset($atts[$att]);
        }
    }

    foreach ($atts as $key => $value) {
        $key = strtolower(trim($key));

        if (!preg_match('/^[a-z_:][a-z_:.0-9-]*$/', $key)) {
            continue;
        }

        $value = trim($value);

        if ('' !== $value) {
            $html .= sprintf(' %s="%s"', $key, esc_attr($value));
        }
    }

    $html = trim($html);

    return $html;
}

function arr_get($array, $key, $default = null) {
    return isset($array[$key]) ? $array[$key] : $default;
}

function print_notice_e($type, $is_dismissible, $message) {
    $dismissable_e = $is_dismissible ? 'is-dismissible' : '';
    echo "<div class='notice notice-$type $dismissable_e'><p>$message</p></div>";
}

function str_nullorempty($string) {
    return (!isset($string) || trim($string) === '');
}

function clean_filename_string($text) {
    $extension = pathinfo($text, PATHINFO_EXTENSION);
    if (empty($extension)) {
        //This seems a gravatar link so we append .jpg to the filename and delete the query
        $query_begin_pos = strpos($text, '?');
        if ($query_begin_pos !== false) {
            $text = mb_substr($text, 0, $query_begin_pos);
        }
        $text .= ".jpg";
    }

    $MAX_FILENAME_LENGTH = 100;
    if (strlen($text) > $MAX_FILENAME_LENGTH):
        $text = mb_substr(basename($text, $extension), 0, $MAX_FILENAME_LENGTH) . ".$extension";
    endif;

    $utf8 = array(
        '/[áàâãªä]/u' => 'a',
        '/[ÁÀÂÃÄ]/u' => 'A',
        '/[ÍÌÎÏ]/u' => 'I',
        '/[íìîï]/u' => 'i',
        '/[éèêë]/u' => 'e',
        '/[ÉÈÊË]/u' => 'E',
        '/[óòôõºö]/u' => 'o',
        '/[ÓÒÔÕÖ]/u' => 'O',
        '/[úùûü]/u' => 'u',
        '/[ÚÙÛÜ]/u' => 'U',
        '/ç/' => 'c',
        '/Ç/' => 'C',
        '/ñ/' => 'n',
        '/Ñ/' => 'N',
        '/–/' => '-', // UTF-8 hyphen to "normal" hyphen
        '/[’‘‹›‚]/u' => ' ', // Literally a single quote
        '/[“”«»„]/u' => ' ', // Double quote
        '/ /' => ' ', // nonbreaking space (equiv. to 0x160)
    );
    return preg_replace(array_keys($utf8), array_values($utf8), $text);
}
