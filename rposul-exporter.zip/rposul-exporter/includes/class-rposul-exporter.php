<?php

/**
 * The file that defines the core plugin class
 *
 * A class definition that includes attributes and functions used across both the
 * public-facing side of the site and the admin area.
 *
 * @link       http://example.com
 * @since      0.1.0
 *
 * @package    Rposul_Exporter
 * @subpackage Rposul_Exporter/includes
 */

/**
 * The core plugin class.
 *
 * This is used to define internationalization, admin-specific hooks, and
 * public-facing site hooks.
 *
 * Also maintains the unique identifier of this plugin as well as the current
 * version of the plugin.
 *
 * @since      0.1.0
 * @package    Rposul_Exporter
 * @subpackage Rposul_Exporter/includes
 * @author     Your Name <email@example.com>
 */
class Rposul_Exporter {

    /**
     * The loader that's responsible for maintaining and registering all hooks that power
     * the plugin.
     *
     * @since    0.1.0
     * @access   protected
     * @var      Rposul_Exporter_Loader    $loader    Maintains and registers all hooks for the plugin.
     */
    protected $loader;

    /**
     * The unique identifier of this plugin.
     *
     * @since    0.1.0
     * @access   protected
     * @var      string    $rposul_exporter    The string used to uniquely identify this plugin.
     */
    protected $rposul_exporter;

    /**
     * The current version of the plugin.
     *
     * @since    0.1.0
     * @access   protected
     * @var      string    $version    The current version of the plugin.
     */
    protected $version;

    /**
     * Define the core functionality of the plugin.
     *
     * Set the plugin name and the plugin version that can be used throughout the plugin.
     * Load the dependencies, define the locale, and set the hooks for the admin area and
     * the public-facing side of the site.
     *
     * @since    0.1.0
     */
    public function __construct() {
        require_once plugin_dir_path(dirname(__FILE__)) . 'includes/class-rposul-exporter-constants.php';

        $this->plugin_name = RPOSUL_PLUGIN_NAME;
        $this->version = RPOSUL_PLUGIN_VERSION;

        $this->load_dependencies();
        $this->set_locale();
        $this->define_admin_hooks();
    }

    /**
     * Load the required dependencies for this plugin.
     *
     * Include the following files that make up the plugin:
     *
     * - Rposul_Exporter_Loader. Orchestrates the hooks of the plugin.
     * - Rposul_Exporter_i18n. Defines internationalization functionality.
     * - Rposul_Exporter_Admin. Defines all hooks for the admin area.
     * - Rposul_Exporter_Public. Defines all hooks for the public side of the site.
     *
     * Create an instance of the loader which will be used to register the hooks
     * with WordPress.
     *
     * @since    0.1.0
     * @access   private
     */
    private function load_dependencies() {
        require_once plugin_dir_path(dirname(__FILE__)) . 'includes/rposul-exporter-functions.php';
        /**
         * The class responsible for orchestrating the actions and filters of the
         * core plugin.
         */
        require_once plugin_dir_path(dirname(__FILE__)) . 'includes/class-rposul-exporter-loader.php';

        /**
         * The class responsible for defining internationalization functionality
         * of the plugin.
         */
        require_once plugin_dir_path(dirname(__FILE__)) . 'includes/class-rposul-exporter-i18n.php';

        /**
         * The class responsible for defining all actions that occur in the admin area.
         */
        require_once plugin_dir_path(dirname(__FILE__)) . 'admin/class-rposul-exporter-admin.php';
        require_once plugin_dir_path(dirname(__FILE__)) . 'admin/class-rposul-exporter-admin-page.php';
        require_once plugin_dir_path(dirname(__FILE__)) . 'admin/class-rposul-exporter-admin-page-main.php';
        require_once plugin_dir_path(dirname(__FILE__)) . 'admin/class-rposul-exporter-admin-page-manage-ads.php';        
        require_once plugin_dir_path(dirname(__FILE__)) . 'admin/class-rposul-exporter-admin-page-manage-insertions.php';
        require_once plugin_dir_path(dirname(__FILE__)) . 'admin/class-rposul-exporter-admin-page-manage-headers.php';
        require_once plugin_dir_path(dirname(__FILE__)) . 'admin/class-rposul-exporter-admin-page-edit-ads.php';

        /**
         * The model classes
         */
        require_once(plugin_dir_path(dirname(__FILE__)) . "admin/models/model-rposul-options.php");
        require_once(plugin_dir_path(dirname(__FILE__)) . "admin/models/model-rposul-pyexporter-comm.php");
        require_once(plugin_dir_path(dirname(__FILE__)) . "admin/models/model-rposul-base-object.php");
        require_once(plugin_dir_path(dirname(__FILE__)) . "admin/models/model-rposul-advertisement.php");
        require_once(plugin_dir_path(dirname(__FILE__)) . "admin/models/model-rposul-page.php");
        require_once(plugin_dir_path(dirname(__FILE__)) . "admin/models/model-rposul-insertion.php");
        require_once(plugin_dir_path(dirname(__FILE__)) . "admin/models/model-rposul-header.php");
        require_once(plugin_dir_path(dirname(__FILE__)) . "admin/models/tex-templates/tex-base-template.php");
        require_once(plugin_dir_path(dirname(__FILE__)) . "admin/models/tex-templates/tex-base-cover-template.php");
        require_once(plugin_dir_path(dirname(__FILE__)) . "admin/models/tex-templates/tex-blank-template.php");
        require_once(plugin_dir_path(dirname(__FILE__)) . "admin/models/tex-templates/tex-columnists-template.php");
        require_once(plugin_dir_path(dirname(__FILE__)) . "admin/models/tex-templates/tex-cover-blank-template.php");
        require_once(plugin_dir_path(dirname(__FILE__)) . "admin/models/tex-templates/tex-cover-simple-four-news.php");
        require_once(plugin_dir_path(dirname(__FILE__)) . "admin/models/tex-templates/tex-cover-bordered-images-five-news.php");
        require_once(plugin_dir_path(dirname(__FILE__)) . "admin/models/tex-templates/tex-cover-bordered-images-four-news.php");
        require_once(plugin_dir_path(dirname(__FILE__)) . "admin/models/tex-templates/tex-small-posts-template.php");
        require_once(plugin_dir_path(dirname(__FILE__)) . "admin/models/tex-templates/tex-one-post-template.php");
        require_once(plugin_dir_path(dirname(__FILE__)) . "admin/models/tex-templates/tex-two-posts-template.php");
        require_once(plugin_dir_path(dirname(__FILE__)) . "admin/models/tex-templates/tex-three-linear-posts-template.php");
        require_once(plugin_dir_path(dirname(__FILE__)) . "admin/models/tex-templates/tex-three-posts-template.php");
        require_once(plugin_dir_path(dirname(__FILE__)) . "admin/models/tex-templates/tex-four-posts-template.php");

        require_once(plugin_dir_path(dirname(__FILE__)) . "admin/models/model-rposul-newspaper.php");


        /**
         * Ajax calls
         */
        require_once plugin_dir_path(__FILE__) . '../admin/rposul-exporter-admin-ajax.php';

        $this->loader = new Rposul_Exporter_Loader();
    }

    /**
     * Define the locale for this plugin for internationalization.
     *
     * Uses the Rposul_Exporter_i18n class in order to set the domain and to register the hook
     * with WordPress.
     *
     * @since    0.1.0
     * @access   private
     */
    private function set_locale() {

        $plugin_i18n = new Rposul_Exporter_i18n();

        $this->loader->add_action('plugins_loaded', $plugin_i18n, 'load_plugin_textdomain');
    }

    /**
     * Register all of the hooks related to the admin area functionality
     * of the plugin.
     *
     * @since    0.1.0
     * @access   private
     */
    private function define_admin_hooks() {

        $plugin_admin = new Rposul_Exporter_Admin($this->get_plugin_name(), $this->get_version());

        $this->loader->add_action('admin_enqueue_scripts', $plugin_admin, 'enqueue_styles');
        $this->loader->add_action('admin_enqueue_scripts', $plugin_admin, 'enqueue_scripts');
        $this->loader->add_action('admin_init', $plugin_admin, 'init');
        $this->loader->add_action('admin_menu', $plugin_admin, 'create_menus');
        $this->loader->add_action('admin_notices', $plugin_admin, 'global_admin_notices');
        $this->loader->add_action('save_post_post', $plugin_admin, 'save_post', 10, 3);
        $this->loader->add_filter('set-screen-option', $plugin_admin, 'set_screen_options', 10, 3);
        //$this->loader->add_action('dbx_post_sidebar', $plugin_admin, 'char_counter', 10, 3);
    }

    /**
     * Run the loader to execute all of the hooks with WordPress.
     *
     * @since    0.1.0
     */
    public function run() {
        $this->loader->run();
    }

    /**
     * The name of the plugin used to uniquely identify it within the context of
     * WordPress and to define internationalization functionality.
     *
     * @since     0.1.0
     * @return    string    The name of the plugin.
     */
    public function get_plugin_name() {
        return $this->plugin_name;
    }

    /**
     * The reference to the class that orchestrates the hooks with the plugin.
     *
     * @since     0.1.0
     * @return    Rposul_Exporter_Loader    Orchestrates the hooks of the plugin.
     */
    public function get_loader() {
        return $this->loader;
    }

    /**
     * Retrieve the version number of the plugin.
     *
     * @since     0.1.0
     * @return    string    The version number of the plugin.
     */
    public function get_version() {
        return $this->version;
    }

}
