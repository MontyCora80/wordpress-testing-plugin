<?php

const RPOSUL_PLUGIN_NAME = "rposul-exporter";
const RPOSUL_PLUGIN_VERSION = "3.3.1";

const RPOSUL_PLACEHOLDER_DEFAULT_IMAGE = "https://placeholdit.imgix.net/~text?txtsize=35&txt=Selecione+a+imagem&w=240&h=240&txttrack=0";
const RPOSUL_PLACEHOLDER_DEFAULT_IMAGE_120 = "https://placeholdit.imgix.net/~text?txtsize=35&txt=Selecione+a+imagem&w=120&h=120&txttrack=0";
const RPOSUL_PUBLISHED_DATE_POST_META = '_rposul_published_date';
const RPOSUL_CONTENT_LENGTH_POST_META = '_rposul_post_content_length';
const RPOSUL_DATE_FORMAT = "Y-m-d"; // this is the database date format, never change this
const RPOSUL_FRONT_END_DATE_FORMAT = "d-m-y";
const RPOSUL_MENU_SLUG = "rposul-exporter";

define('RPOSUL_IS_DEBUG', false); //THE MASTER KEY

define('USE_LOCAL_SERVER', false);
define('USE_PAMPA_SERVER', true);
define('USE_DEBUG_SERVER_VERSION', (true || USE_LOCAL_SERVER) && RPOSUL_IS_DEBUG);

define('DISABLE_COMM', true && RPOSUL_IS_DEBUG);
define('DISABLE_GENERATE', false && RPOSUL_IS_DEBUG);
define('DISABLE_COVER_GENERATION', false && RPOSUL_IS_DEBUG);
define('DISABLE_NEWSPAPER_CLOSE_ACTION', false && RPOSUL_IS_DEBUG);
define('DISABLE_AUTOMATIC_NEWSPAPER_DATE_SETTER', TRUE || RPOSUL_IS_DEBUG);

define('RPOSUL_TEMPLATEID_THREE_LINEAR_POSTS', 1);
define('RPOSUL_TEMPLATEID_COLUMNISTS', 2);
//define('RPOSUL_TEMPLATEID_REPORTAGE', 3); deprecated
define('RPOSUL_TEMPLATEID_SMALL_NEWS', 4);
define('RPOSUL_TEMPLATEID_ONE_PAGE', 5);
define('RPOSUL_TEMPLATEID_COVER_SIMPLE_FOUR_NEWS', 6);
define('RPOSUL_TEMPLATEID_COVER_ALTERNATE', 7);
define('RPOSUL_TEMPLATEID_BLANK', 8);
define('RPOSUL_TEMPLATEID_COVER_BORDERED_IMAGE_FOUR_NEWS', 9);
define('RPOSUL_TEMPLATEID_COVER_BORDERED_IMAGE_FIVE_NEWS', 10);
//define('RPOSUL_TEMPLATEID_ECONOMY', 11); deprecated
define('RPOSUL_TEMPLATEID_TWO_PER_PAGE', 12);
define('RPOSUL_TEMPLATEID_THREE_PER_PAGE', 13);
define('RPOSUL_TEMPLATEID_COVER_BLANK', 14);
define('RPOSUL_TEMPLATEID_FOUR_PER_PAGE', 15);

if (USE_PAMPA_SERVER) {
    define('RPOSUL_SERVICE_URL', 'http://pdf.osul.com.br/wpgen/');
} else if (USE_LOCAL_SERVER) {
    define('RPOSUL_SERVICE_URL', 'http://localhost/wpgen/');
} else {
    define('RPOSUL_SERVICE_URL', 'http://ec2-52-67-57-127.sa-east-1.compute.amazonaws.com/');
}

class Rposul_Exporter_Constants {

    public static $template_ids = array(
        //RPOSUL_TEMPLATEID_THREE_LINEAR_POSTS => 'Três posts verticais',
        RPOSUL_TEMPLATEID_BLANK => 'Em branco',
        RPOSUL_TEMPLATEID_COLUMNISTS => 'Colunistas',
        RPOSUL_TEMPLATEID_SMALL_NEWS => 'Pequenos posts',
        //RPOSUL_TEMPLATEID_ECONOMY => 'Economia',
        //RPOSUL_TEMPLATEID_REPORTAGE => 'Reportagem',
        RPOSUL_TEMPLATEID_ONE_PAGE => 'Uma por página',
        RPOSUL_TEMPLATEID_TWO_PER_PAGE => 'Duas por página',
        RPOSUL_TEMPLATEID_THREE_PER_PAGE => 'Três por página',
        RPOSUL_TEMPLATEID_FOUR_PER_PAGE => 'Quatro por página');
    
    public static $template_cover_ids = array(
        RPOSUL_TEMPLATEID_COVER_SIMPLE_FOUR_NEWS => array("name" => 'Capa 4 Posts Simples', 'image' => 'coverfournews.jpg'),
        RPOSUL_TEMPLATEID_COVER_BORDERED_IMAGE_FOUR_NEWS => array("name" => 'Capa 4 Posts Duas Imagens', 'image' => 'coverfournews.jpg'),
        RPOSUL_TEMPLATEID_COVER_BORDERED_IMAGE_FIVE_NEWS => array("name" => 'Capa 5 Posts Duas Imagens', 'image' => 'coverfournews.jpg'),
    );

}
