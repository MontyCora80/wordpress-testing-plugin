

(function ($) {
    'use strict';
    $("form#generate").submit(function (e) {
        // this code prevents form from actually being submitted
        e.preventDefault();
        e.returnValue = false;

        var page = 0;
        if ($("#rposul_exporter_main_export_page_check")[0].checked) {
            page = $('#rposul_exporter_main_export_page').val();
        }
        var $form = $(this);
        var data = {
            'action': 'check_newspaper_for_errors',
            'page': page
        };
        $.post(ajaxurl, data,
                function (response) {
                    if (response.success) {
                        $form.off('submit');
                        $form.submit();
                    } else {
                        var message = "";
                        for (var key in response.data) {
                            var single_message = response.data[key];
                            if (message.indexOf(single_message) === -1) {
                               message += single_message + "\n";
                            }
                        }
                        if (confirm(message + "\nDeseja continuar?")) {
                            $form.off('submit');
                            $form.submit();
                        } else {
                            $.unblockUI();
                        }
                    }
                })
                .fail(function () {
                    alert('Não foi possível validar a edição a ser gerada');
                    $.unblockUI();
                });

    });

})(jQuery);