/* global post_selection_object */

(function ($) {

    var DATE_FORMAT = post_selection_object.date_format; //'yy-mm-dd';
    var CLASS_UI_STATE_ALREADY_SELECTED = 'ui-state-disabled';
    var filteredList;
    var modal_css = {
        'z-index': 11000,
        width: '40%',
        top: '10%',
        left: '30%',
        right: '30%',
        border: 'none',
        padding: '5px',
        overflow: 'auto',
        'max-height': '80%',
        backgroundColor: '#fff',
        '-webkit-border-radius': '10px',
        '-moz-border-radius': '10px',
        cursor: 'default',
        color: '#000'};

    function remake_target_page_numbers() {
        var container_ul = $('#post-selection-target-sortable-wrap');
        container_ul.find('.sortable-target-item-header-page').each(function (key, value) {
            $(this).text(key + 1);
        });
    }

    function update_settings_options(templateid) {
        var template_settings = post_selection_object.template_settings[parseInt(templateid)];
        if (template_settings && template_settings.has_title) {
            $('#page-options-modal-extra-title-row').show();
        } else {
            $('#page-options-modal-extra-title-row').hide();
        }
    }

    function show_page_errors(ajax_response) {
        var errorClassName = 'sortable-target-posts-error';
        var warningClassName = 'sortable-target-posts-warning';

        $('.sortable-target-item-header').each(function (index, elem) {
            var $elem = $(elem);
            $noticeelem = $elem.children('.sortable-target-item-header-notice');
            $ulelem = $elem.parent().children('.sortable-target-posts');

            var pageid = $elem.data('pageid').toString();
            if (typeof (ajax_response) === 'object' && ajax_response !== null && pageid in ajax_response) {
                var errors = ajax_response[pageid]['errors'];
                var has_error = 'error' in  errors || 'internal_error' in errors;
                var has_warning = 'warning' in errors;
            } else {
                var has_error = false;
                var has_warning = false;
            }
            if (has_error) {
                $noticeelem.text('Erro');
            } else if (has_warning) {
                $noticeelem.text('Aviso');
            } else {
                $noticeelem.text('');
            }

            // Issue #873 Issue #707
            //$elem.toggleClass(errorClassName, has_error );
            //$ulelem.toggleClass(errorClassName, has_error);
            //
            //$elem.toggleClass(warningClassName, !has_error && has_warning);
            //$ulelem.toggleClass(warningClassName, !has_error && has_warning);
            // Following lines in place of above
            $elem.toggleClass(errorClassName, has_error || has_warning);
            $ulelem.toggleClass(errorClassName, has_error || has_warning);
        });
    }

    function update_sortable(event, ui) {
        var sender = ui.sender; // is != undefined if the target is receivign
        var start_page = ui.item.data("startpageid");
        var end_page = ui.item.parent().data("pageid");
        var post_id = ui.item.data("postid");
        var advertisement_id = ui.item.data("adid");
        var insertion_id = ui.item.data("insertionid");
        var innerthis = $(this);

        var has_adid = typeof advertisement_id !== "undefined";
        var has_postid = typeof post_id !== "undefined";
        var has_insertionid = typeof insertion_id !== "undefined";
        var has_sp = typeof start_page !== "undefined";
        var has_ep = typeof end_page !== "undefined";
        var has_sender = sender !== null;
        var is_sp_eq_ep = start_page === end_page;

        var execute_ajax = (has_ep && !has_sender) || (has_sp && has_ep && is_sp_eq_ep);
        if (execute_ajax) {
            var data = false;

            if (has_postid) {
                var end_page_position = false;
                var res_items = ui.item.parent().find('li[data-postid]');
                for (var i = 0; i < res_items.length; i++) {
                    if (res_items.get(i) === ui.item.get(0)) {
                        end_page_position = i;
                        break;
                    }
                }
                if (end_page_position === false) {
                    //error finding target position
                    innerthis.sortable('cancel');
                    return;
                }

                data = {
                    'action': 'move_post',
                    'post_id': post_id,
                    'source_page': start_page,
                    'target_page': end_page,
                    'target_page_position': end_page_position
                };

            } else if (has_adid) {
                var end_page_position = false;
                var res_items = ui.item.parent().find('li[data-adid]');
                for (var i = 0; i < res_items.length; i++) {
                    if (res_items.get(i) === ui.item.get(0)) {
                        end_page_position = i;
                        break;
                    }
                }
                if (end_page_position === false) {
                    //error finding target position
                    innerthis.sortable('cancel');
                    return;
                }

                data = {
                    'action': 'move_advertisement',
                    'advertisement_id': advertisement_id,
                    'source_page': start_page,
                    'target_page': end_page,
                    'target_page_position': end_page_position
                };
            } else if (has_insertionid) {
                data = {
                    'action': 'move_insertion',
                    'insertion_id': insertion_id,
                    'source_page': start_page,
                    'target_page': end_page
                };
            }
            if (data) {
                $.blockUI({message: null});
                $.post(ajaxurl, data,
                        function (response) {
                            show_page_errors(response);
                        })
                        .fail(function () {
                            alert('Ocorreu um erro ao mover o item. A operação será revertida.');
                            innerthis.sortable('cancel');
                        })
                        .always(function () {
                            $.unblockUI();
                        });
            }
        }
    }

    function trash_post_click() {
        var list_item = $(this).parent();

        var post_id = list_item.data('postid');
        var advertisement_id = list_item.data('adid');
        var insertion_id = list_item.data('insertionid');

        var has_adid = typeof advertisement_id !== "undefined";
        var has_postid = typeof post_id !== "undefined";
        var has_insertionid = typeof insertion_id !== "undefined";

        var list = list_item.parent();

        if (confirm("Tem certeza que remover o post desta edição?") !== true) {
            return;
        }

        if (has_postid) {
            var data = {
                'action': 'move_post',
                'post_id': post_id,
                'source_page': list.data('pageid'),
                'source_page_position': list_item.index()
            };
            $.blockUI({message: null});
            $.post(ajaxurl, data,
                    function (response) {
                        list_item.remove();
                        $('.sortable-source-posts').find("[data-postid='" + data.post_id + "']").removeClass(CLASS_UI_STATE_ALREADY_SELECTED);
                        show_page_errors(response);
                    })
                    .fail(function () {
                        alert("Não foi possível apagar post.");
                    })
                    .always(function () {
                        $.unblockUI();
                    });
        } else if (has_adid) {
            var data = {
                'action': 'move_advertisement',
                'advertisement_id': advertisement_id,
                'source_page': list.data('pageid'),
                'source_page_position': list_item.index()
            };
            $.blockUI({message: null});
            $.post(ajaxurl, data,
                    function (response) {
                        list_item.remove();
                        show_page_errors(response);
                    })
                    .fail(function () {
                        alert("Não foi possível apagar anúncio.");
                    })
                    .always(function () {
                        $.unblockUI();
                    });
        } else if (has_insertionid) {
            var data = {
                'action': 'move_insertion',
                'insertion_id': insertion_id,
                'source_page': list.data('pageid')
            };
            $.blockUI({message: null});
            $.post(ajaxurl, data,
                    function (response) {
                        list_item.remove();
                        show_page_errors(response);
                    })
                    .fail(function () {
                        alert("Não foi possível apagar editorial.");
                    })
                    .always(function () {
                        $.unblockUI();
                    });
        }
    }

    function open_settings_click() {
        var page_number = $(this).parent().find('.sortable-target-item-header-page').text();
        $('#page-options-modal caption').text("Página " + page_number);
        $('#page-options-modal-save').data('target', $(this).parent());

        $('#page-options-modal-delete').data('target', $(this).parent().parent());
        $('#page-options-modal-delete').data('pageid', $(this).parent().data('pageid'));

        $('#page-options-modal-move').data('target', $(this).parent().parent());
        $('#page-options-modal-move').data('pageid', $(this).parent().data('pageid'));
        $('#page-options-modal-move').data('pagenumber', page_number);

        var templateid = $(this).parent().data('templateid');
        var headerid = $(this).parent().data('headerid');


        // We need to concat between '' for when the value is undefined
        var template_select = $("#page-options-modal-templateid");
        var header_select = $("#page-options-modal-headerid");

        var template_option = $("#page-options-modal-templateid option[value='" + templateid + "']");
        var header_option = $("#page-options-modal-headerid option[value='" + headerid + "']");

        if (template_option.length) {
            template_option.prop("selected", true);
        } else {
            $("#page-options-modal-templateid option[value='']").prop("selected", true);
        }

        if (header_option.length) {
            header_option.prop("selected", true);
        } else {
            $("#page-options-modal-headerid option:eq(0)").prop("selected", true);
        }

        update_settings_options(templateid);

        var extravalues = $(this).parent().data('extravalues');
        $('.modal-extra-value').each(function (key, value) {
            var $input = $(value);
            var input_name = $input.attr('name');
            if (input_name && extravalues.hasOwnProperty(input_name)) {
                $input.val(extravalues[input_name]);
            } else {
                $input.val('');
            }
        });

        $.blockUI({message: $('#page-options-modal'),
            css: modal_css});

        $('.blockOverlay').css('cursor', 'auto').click($.unblockUI);
    }

    function initSortableTarget() {
        $('.sortable-target-posts').sortable({
            items: 'li',
            connectWith: '.sortable-target-page > ul, .sortable-target-cover > ul',
            start: function (event, ui) {
                $(ui.item).data("startpageid", ui.item.parent().data("pageid"));
            },
            update: update_sortable
        }).disableSelection();
    }

    function initSortableSource() {
        $('.sortable-source-posts').sortable({
            connectWith: '.sortable-target-page > ul, .sortable-target-cover > ul',
            update: update_sortable,
            remove: function (e, li) {
                li.item.clone().insertAfter(li.item);
                $(this).sortable('cancel');
                $(this).find("[data-postid='" + li.item.data('postid') + "']")
                        .addClass(CLASS_UI_STATE_ALREADY_SELECTED);
                return true;
            }

        }).disableSelection();
    }

    $(document).ready(function () {
        filteredList = $('.sortable-source-posts')
                .listfilter({textbox: $('#filter-source-posts')});


        $('#filter-target-pages').bind('change keyup', function () {
            var filter_values = $(this).val().replace(" ", "").split(',').filter(function (v) {
                return $.isNumeric(v);
            });

            if (filter_values.length) {
                $('#post-selection-target-sortable-wrap > li').hide();

                $.each(filter_values, function (key, value) {
                    if ($.isNumeric(value)) {
                        $('#post-selection-target-sortable-wrap > li:nth-child(' + value + ')').show();
                    }
                });
            } else {
                $('#post-selection-target-sortable-wrap > li').show();
            }
        });

        $("#date-source-posts").datepicker({
            dateFormat: DATE_FORMAT,
            defaultDate: $("#date-source-posts").val()});

        $("#search-posts-by-date").click(function () {
            $('#post-selection-source').block({message: null});
            var data = {
                'action': 'get_posts_by_date',
                'date': $("#date-source-posts").val()
            };
            $.post(ajaxurl, data,
                    function (response) {
                        $('.sortable-source-posts').html(response);
                        filteredList.listfilter("clear");

                    }).
                    always(function () {
                        $('#post-selection-source').unblock({
                            onUnblock: function () {
                                $('#post-selection-source').removeAttr('style');
                            }
                        });
                    })
                    .fail(function () {
                        console.log('fail');
                    });
        });

        $('.sortable-target-posts').on(
                'click',
                'button.ui-sortable-trash',
                trash_post_click
                );

        $(".add-blank-page").click(function () {
            $('#page-add-modal-quantity').val(1);

            var total_pages = $('#post-selection-target-sortable-wrap > li').length;
            $('#page-add-modal-position').val(total_pages + 1);

            $.blockUI({message: $('#page-add-modal'), css: modal_css});
            $('.blockOverlay').css('cursor', 'auto').click($.unblockUI);
        });

        $(".newspaper-options").click(function () {
            $.blockUI({message: $('#newspaper-options-modal'), css: modal_css});
            $('.blockOverlay').css('cursor', 'auto').click($.unblockUI);
        });

        $('#page-add-modal-apply').click(function () {
            var quantity_added = $('#page-add-modal-quantity').val();
            var position = $('#page-add-modal-position').val();
            var data = {
                'action': 'add_newspaper_pages',
                'quantity': quantity_added,
                'position': position
            };
            $.blockUI({message: null});
            $.post(ajaxurl, data,
                    function (response) {
                        var total_pages = $('#post-selection-target-sortable-wrap > li').length;
                        var position_added = $('#page-add-modal-position').val();
                        for (var i = 0, max = quantity_added; i < max; i++) {
                            var osul_clone = $($('#post-selection-target-sortable-wrap').children()[0]).clone();
                            osul_clone.addClass('sortable-target-page').removeClass('sortable-target-cover');
                            osul_clone.find('.sortable-target-item-header .sortable-target-item-header-page').text(response.pagenumbers[i]);
                            osul_clone.on('click', '.sortable-target-item-header-settings', open_settings_click);
                            osul_clone.on('click', 'button.ui-sortable-trash', trash_post_click);
                            var inner_list = osul_clone.find('ul');
                            inner_list.empty();
                            inner_list.data('pageid', response.pageids[i]);
                            osul_clone.find('> div').data('pageid', response.pageids[i]);
                            if (position_added > total_pages) {
                                $('#post-selection-target-sortable-wrap').append(osul_clone);
                            } else {
                                osul_clone.insertBefore($('#post-selection-target-sortable-wrap > li:nth-child(' + (parseInt(position_added) + i) + ')'));
                            }
                        }
                        remake_target_page_numbers();
                        initSortableTarget();
                        reload_page_errors();
                    })
                    .always(function () {
                        $.unblockUI();
                    })
                    .fail(function () {
                        console.log('fail');
                    });
        });

        $('.sortable-target-item-header-settings').on('click', open_settings_click);

        $("#page-options-modal-templateid").change(function (object) {
            // this was a manual selection
            var template_settings = post_selection_object.template_settings[parseInt($(this).val())];
            if (template_settings && template_settings.auto_header) {
                $("#page-options-modal-headerid option[value='" + template_settings.auto_header + "']").prop('selected', true);
            }

            update_settings_options($(this).val());
        });


        $('.page-options-modal-close').click($.unblockUI);
        $('#page-options-modal-save').click(function () {
            var target = $(this).data('target');
            var selected_templateid = $("#page-options-modal-templateid option:selected").val();
            var selected_headerid = $("#page-options-modal-headerid option:selected").val();
            var extra_values = {};
            $(".modal-extra-value:visible").each(function (key, value) {
                var $input = $(value);
                if ($input.attr('name') && $input.val()) {
                    extra_values[$input.attr('name')] = $input.val();
                }
            });
            if (target) {
                var data = {
                    'action': 'save_page_settings',
                    'page_id': target.data('pageid'),
                    'header_id': selected_headerid,
                    'template_id': selected_templateid,
                    'extra_values': extra_values
                };
                $.unblockUI();
                $.blockUI({message: null});
                $.post(ajaxurl, data,
                        function (response) {
                            target.data('templateid', selected_templateid);
                            target.data('headerid', selected_headerid);
                            target.data('extravalues', extra_values);
                            reload_page_errors();
                        })
                        .fail(function () {
                            alert("Não foi possível alterar as opções.");
                        })
                        .always(function () {
                            $.unblockUI();
                        });
            }
        });

        $('#page-options-modal-move').click(function () {
            var target = $(this).data('target');
            if (target) {
                var page_number = $(this).data('pagenumber');
                $('#page-move-modal caption').text("Página " + page_number);
                $('#page-move-modal-apply').data('pageid', $(this).data('pageid'));
                $('#page-move-modal-apply').data('target', target);
                $('#page-move-modal-number').val(page_number);
                $.blockUI({message: $('#page-move-modal'), css: modal_css});
                $('.blockOverlay').css('cursor', 'auto').click($.unblockUI);
            }
        });


        $('#page-move-modal-apply').click(function () {
            var target = $(this).data('target');
            var target_page_position = $('#page-move-modal-number').val();

            if (target_page_position <= 1) {
                return;
            }

            if (target) {
                var data = {
                    'action': 'move_page',
                    'page_id': $(this).data('pageid'),
                    'target_position': target_page_position
                };

                $.unblockUI();
                $.blockUI({message: null});
                $.post(ajaxurl, data,
                        function (response) {
                            console.log(response);
                            var current_position = target.index();
                            if (target_page_position <= current_position) {
                                target.insertBefore($('#post-selection-target-sortable-wrap > li:nth-child(' + target_page_position + ')'));
                            } else {
                                var number_of_items = $('#post-selection-target-sortable-wrap > li').length;
                                if (target_page_position > number_of_items) {
                                    target_page_position = number_of_items;
                                }
                                target.insertAfter($('#post-selection-target-sortable-wrap > li:nth-child(' + target_page_position + ')'));
                            }
                            remake_target_page_numbers();
                        })
                        .fail(function () {
                            alert("Não foi possível mover a página.");
                        })
                        .always(function () {
                            $.unblockUI();
                        });
            }
        });

        $('#page-options-modal-delete').click(function () {
            var target = $(this).data('target');
            if (target) {
                $.unblockUI();
                if (target.find('li[data-adid]').length || target.find('li[data-insertionid]').length) {
                    alert('Não é possível remover páginas com anúncios ou editorias');
                    return;
                }

                if (confirm("Tem certeza que deseja remover a página desta edição?") !== true) {
                    return;
                }

                var data = {
                    'action': 'delete_newspaper_page',
                    'page_id': $(this).data('pageid')
                };
                $.blockUI({message: null});
                $.post(ajaxurl, data,
                        function (response) {
                            target.find('li').each(function (key, value) {
                                $('.sortable-source-posts').find("[data-postid='" + $(value).data('postid') + "']").removeClass(CLASS_UI_STATE_ALREADY_SELECTED);
                            });
                            target.remove();
                            remake_target_page_numbers();
                        })
                        .fail(function () {
                            alert("Não foi possível alterar as opções.");
                        })
                        .always(function () {
                            $.unblockUI();
                        });
            }
        });

        initSortableSource();
        initSortableTarget();

        reload_page_errors();

        var $window = $(window),
                $stickyEl = $('#post-selection-source'),
                elTop = $stickyEl.offset().top;

        $window.scroll(function () {
            $stickyEl.toggleClass('post-selection-source-sticky', $window.scrollTop() > elTop);
        });

        $('#order-posts-by-size').click(function () {
            $('.sortable-source-posts').html($('.sortable-source-posts').children('li').sort(function (a, b) {
                return $(a).data('size') - $(b).data('size');
            }));
        });

        $('#order-posts-by-date').click(function () {
            $('.sortable-source-posts').html($('.sortable-source-posts').children('li').sort(function (a, b) {

                var date_a = new Date($(a).data('date'));
                var date_b = new Date($(b).data('date'));

                return date_b.getTime() - date_a.getTime();
            }));
        });
    });

    function reload_page_errors() {
        var data = {
            'action': 'get_pages_error'
        };
        // since 2.8 ajaxurl is always defined in the admin header and points to admin-ajax.php
        $.post(ajaxurl, data, function (response) {
            show_page_errors(response);
        });
    }

})(jQuery);