(function ($) {
    'use strict';
    var dateFormat = 'yy-mm-dd';
    var setIntervalHandler = null;
    $(function () {

        /***
         * Date pickers
         */
        $.datepicker.regional[ "pt-BR" ] = {
            closeText: "Fechar",
            prevText: "&#x3C;Anterior",
            nextText: "Próximo&#x3E;",
            currentText: "Hoje",
            monthNames: ["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho",
                "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"],
            monthNamesShort: ["Jan", "Fev", "Mar", "Abr", "Mai", "Jun",
                "Jul", "Ago", "Set", "Out", "Nov", "Dez"],
            dayNames: [
                "Domingo",
                "Segunda-feira",
                "Terça-feira",
                "Quarta-feira",
                "Quinta-feira",
                "Sexta-feira",
                "Sábado"
            ],
            dayNamesShort: ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"],
            dayNamesMin: ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"],
            weekHeader: "Sm",
            dateFormat: "dd/mm/yy",
            firstDay: 0,
            isRTL: false,
            showMonthAfterYear: false,
            yearSuffix: ""
        };
        $.datepicker.setDefaults($.datepicker.regional[ "pt-BR" ]);
        var news_date = $("#news_date").datepicker({
            dateFormat: dateFormat,
            defaultDate: $('#news_date').val()})
                .on('change', function () {
                    var date = getDate(this);
                    date.setDate(date.getDate() - 1);
                    to.datepicker("setDate", date);
                    from.datepicker("setDate", date);
                }), from = $("#article_range_start").datepicker({
            dateFormat: dateFormat,
            defaultDate: $('#article_range_start').val()})
                .on("change", function () {
                    to.datepicker("option", "minDate", getDate(this));
                }), to = $("#article_range_end").datepicker({
            dateFormat: dateFormat,
            defaultDate: $('#article_range_end').val()})
                .on("change", function () {
                    var maxDate = getDate(this);
                    maxDate.setDate(maxDate.getDate() - 1);
                    from.datepicker("option", "maxDate", maxDate);
                });
        $("#news_dismantle_date").datepicker({
            dateFormat: dateFormat,
            defaultDate: $('#news_dismantle_date').val()});        

        
        $("#rposul_exporter_main_export_page_check").click(function(){
            $('#rposul_exporter_main_export_page').prop('disabled', !this.checked);
        });
        
        $("form.dirty-check").areYouSure();
        $('form.dirty-check').on('dirty.areYouSure', function () {
            // Enable save button only as the form is dirty.
            $(this).find('input[type="submit"]').removeAttr('disabled');
        });
        $('form.dirty-check').on('clean.areYouSure', function () {
            // Form is clean so nothing to save - disable the save button.
            $(this).find('input[type="submit"]').attr('disabled', 'disabled');
        });

        //$("select").imagepicker()        
       
        var progressbar = $("#progressbar"),
                progressLabel = $(".progress-label");
        progressbar.progressbar({
            value: progressbar.data("progress-value"),
            max: progressbar.data("progress-max"),
            change: function () {
                progressLabel.text(progressbar.progressbar("value") + "/" +
                        progressbar.progressbar("option", "max"));
            },
            complete: function () {
                if (progressbar.progressbar("option", "max") !== 0) {
                    progressLabel.text("Pronto!");
                } else {
                    progressLabel.text("");
                }
            }
        });

        if ($("#osul-pdf-show-spinner:visible").length > 0) {
            setIntervalHandler = setInterval(function () {
                var data = {
                    'action': 'get_generate_status'
                };
                $.post(ajaxurl, data,
                        function (response) {
                            if (response.current_page !== null) {
                                progressbar.progressbar("option", "max", response.total_pages);
                                progressbar.progressbar("value", response.current_page);
                            }

                            if (response.done) {
                                $("#osul-pdf-show").removeAttr('disabled');
                                $("#osul-pdf-show").removeAttr('onclick');
                                $("#progresscancel").hide();
                                $("#osul-pdf-show-spinner").hide();
                                $("#osul-generate-close").hide();
                                $("#osul-generate-checkmark").show();

                                clearInterval(setIntervalHandler);
                            }

                            if (!response.done && !response.running) {
                                clearInterval(setIntervalHandler);
                            }
                        });
            }, 5000);
        }

        $('#rposul_exporter_main_export_pdf_quick, #rposul_exporter_main_export_pdf_close').click(function () {
            $.blockUI({message: "<h1>Aguarde ... </h1>"});
        });

        $('.remote-log-show').click(function () {
            $.unblockUI;
            $.blockUI({message: '<h1>Carregando ... </h1>'});
            var data = {'action': 'get_remote_log'};
            $.post(ajaxurl, data,
                    function (response) {
                        $('#remote-log-data-text').html(response);
                        $.unblockUI();
                        $.blockUI({message: $('#remote-log-data'),
                            css: {
                                'z-index': 11000,
                                width: '90%',
                                top: '10%',
                                left: '5%',
                                right: '5%',
                                border: 'none',
                                padding: '5px',
                                overflow: 'auto',
                                'max-height': '80%',
                                backgroundColor: '#fff',
                                '-webkit-border-radius': '10px',
                                '-moz-border-radius': '10px',
                                opacity: .95,
                                color: '#000'}});
                        $('.blockOverlay').css('cursor', 'auto').click($.unblockUI);
                        $('#remote-log-close').click($.unblockUI);
                    });
        });
        $(document).keyup(function (e) {
            if (e.keyCode === 27) { // escape key maps to keycode `27`
                $.unblockUI();
            }
        });

        $('#category-uncheck-all').click(function (e) {
            $('#rposul_exporter_category_checklist input').each(
                    function (index, elem) {
                        $(elem).removeAttr('checked');
                    }
            );
            e.preventDefault();
            return false;
        });

        $(".rposul-disabled-interactions *").disable();

        $("#rposul-ad-section").change(function ($selected) {
            if ($("#rposul-ad-section option:selected").data('templateid') === 0) {
                $("#rposul-ad-section-pages-div").show();
            } else {
                $("#rposul-ad-section-pages-div").hide();
            }
        });
        
    });
    function getDate(element) {
        var date;
        try {
            date = $.datepicker.parseDate(dateFormat, element.value);
        } catch (error) {
            date = null;
        }
        return date;
    }


})(jQuery);
