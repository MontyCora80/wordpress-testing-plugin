/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

(function ($) {
    $.widget("osul.listfilter", {
        options: {
            textbox: null
        },
        clear: function () {
            $(this.options.textbox).val("").change();
            return this;
        },
        _create: function () {
            var list = this.element;

            $(this.options.textbox).bind('change keyup', function () {
                var search = $.trim($(this).val());
                var regex = new RegExp(search, "gi");

                $.each(list.children(), function () {
                    if ($(this).text().match(regex) !== null) {
                        $(this).removeClass('ui-state-filtered');
                    } else {
                        $(this).addClass('ui-state-filtered');
                    }
                });
            });
        }
    });

    $.widget("osul.imageselector", {
        _create: function () {
            this.element.click(function () {
                var picker_id = $(this).data('picker-id');
                var media = new THB_MediaSelector({
                    type: 'image',
                    close: function () {
                        /*var correspondantpickerid = $(".upload_image_thumbnail:visible").filter('[data-picker-id="' + picker_id + '"]');
                         if (correspondantpickerid.length > 0) {
                         //We are on a dynamic environment where picker ids exists
                         var inputelement = $("form:visible input:hidden").filter('[data-picker-id="' + picker_id + '"]');
                         inputelement.val("");
                         inputelement.change();
                         correspondantpickerid[0].src = 'http://placehold.it/120x120';
                         
                         }*/
                    },
                    select: function (selected_images) {
                        var correspondantpickerid = $(".upload_image_thumbnail:visible").filter('[data-picker-id="' + picker_id + '"]');
                        if (correspondantpickerid.length > 0) {
                            //We are on a dynamic environment where picker ids exists
                            correspondantpickerid[0].src = selected_images.url;
                            var inputelement = $("form:visible input:hidden").filter('[data-picker-id="' + picker_id + '"]');
                            inputelement.val(selected_images.id);
                            inputelement.change();
                        }
                    }
                });

                media.open();
                // You can pass an array of attachments IDs, to pre-select them: media.open( [ 23, 145 ] );
                // More than one value passed will only work if the 'multiple' option has been set to TRUE.            
                return false;
            });
        }
    });

    $.widget("osul.newimageselector", {
        options: {
            placeholder: '',
            width: 240,
            height: 240
        },

        _create: function () {
            this.image = $("<img>").attr('src', this.options.placeholder);
            
            var input_name =  this.element.data('input-name');
            if (!input_name){
                //Compatibility
                //This is obsolete and should be deprecated
                console.log('"picker-id" is deprecated. Please use "input-name" instead');
                input_name = 'imageselector[' + this.element.data('picker-id') + ']';
            }
            
            this.input = $('<input>').attr({
                type: 'hidden',
                name: input_name
            });
            $("<div>").addClass("selected_image_container")
                    .append(this.image)
                    .append(this.input)
                    .insertBefore(this.element);

            var innerthis = this;
            this.element.click(function () {
                var media = new THB_MediaSelector({
                    type: 'image',
                    close: function () {
                        /*var correspondantpickerid = $(".upload_image_thumbnail:visible").filter('[data-picker-id="' + picker_id + '"]');
                         if (correspondantpickerid.length > 0) {
                         //We are on a dynamic environment where picker ids exists
                         var inputelement = $("form:visible input:hidden").filter('[data-picker-id="' + picker_id + '"]');
                         inputelement.val("");
                         inputelement.change();
                         correspondantpickerid[0].src = 'http://placehold.it/120x120';
                         
                         }*/
                    },
                    select: function (selected_images) {
                        innerthis.image.attr('src', selected_images.url);
                        innerthis.input.val(selected_images.id);
                    }
                });

                media.open();
                // You can pass an array of attachments IDs, to pre-select them: media.open( [ 23, 145 ] );
                // More than one value passed will only work if the 'multiple' option has been set to TRUE.            
                return false;
            });
        }
    });

    $.widget("osul.combobox", {
        _create: function () {
            this.wrapper = $("<span>")
                    .addClass("custom-combobox")
                    .insertAfter(this.element);

            this.element.hide();
            this._createAutocomplete();
            this._createShowAllButton();
        },
        _createAutocomplete: function () {
            var selected = this.element.children(":selected"),
                    value = selected.val() ? selected.text() : "";

            this.input = $("<input>")
                    .appendTo(this.wrapper)
                    .val(value)
                    .attr("title", "")
                    .addClass("custom-combobox-input ui-widget ui-widget-content ui-state-default ui-corner-left")
                    .autocomplete({
                        delay: 0,
                        minLength: 0,
                        source: $.proxy(this, "_source")
                    })
                    .tooltip({
                        classes: {
                            "ui-tooltip": "ui-state-highlight"
                        }
                    });

            this._on(this.input, {
                autocompleteselect: function (event, ui) {
                    ui.item.option.selected = true;
                    this._trigger("select", event, {
                        item: ui.item.option
                    });
                    this.element.change();
                },
                autocompletechange: "_removeIfInvalid",
                autocompleteclose: "_removeIfInvalid"
            });
        },
        _createShowAllButton: function () {
            var input = this.input,
                    wasOpen = false;

            $("<a>")
                    .attr("tabIndex", -1)
                    .attr("title", "Mostrar todos")
                    .tooltip()
                    .appendTo(this.wrapper)
                    .button({
                        icons: {
                            primary: "ui-icon-triangle-1-s"
                        },
                        text: false
                    })
                    .removeClass("ui-corner-all")
                    .addClass("custom-combobox-toggle ui-corner-right")
                    .on("mousedown", function () {
                        wasOpen = input.autocomplete("widget").is(":visible");
                    })
                    .on("click", function () {
                        input.trigger("focus");

                        // Close if already visible
                        if (wasOpen) {
                            return;
                        }

                        // Pass empty string as value to search for, displaying all results
                        input.autocomplete("search", "");
                    });
        },
        _source: function (request, response) {
            var matcher = new RegExp($.ui.autocomplete.escapeRegex(request.term), "i");
            var combobox_options = this.element.children("option").map(function () {
                var text = $(this).text();
                if (this.value && (!request.term || matcher.test(text)))
                    return {
                        label: text,
                        value: text,
                        option: this
                    };
            });
            function compare(a, b) {
                if (a.label < b.label)
                    return -1;
                if (a.label > b.label)
                    return 1;
                return 0;
            }
            combobox_options.sort(compare);
            response(combobox_options);
        },
        _removeIfInvalid: function (event, ui) {

            // solving an issue where sometimes the trigger change would not
            // be called when we are manually deleting the text and clicking
            // outside                
            if (event.type === 'autocompleteclose') {
                if (this.input.val() === "" && this.element.val() !== "") {
                    this.element.val("").trigger("change");
                } else {
                    return;
                }
            }
            // Selected an item, nothing to do
            if (ui.item) {
                return;
            }

            // Search for a match (case-insensitive)
            var value = this.input.val(),
                    valueLowerCase = value.toLowerCase(),
                    valid = false;
            this.element.children("option").each(function () {
                if ($(this).text().toLowerCase() === valueLowerCase) {
                    this.selected = valid = true;
                    $(this.parentElement).change();
                    return false;
                }
            });            

            // Found a match, nothing to do
            if (valid) {
                return;
            }

            // Remove invalid value
            this.input
                    .val("")
                    .attr("title", value + " não corresponde a nenhuma notícia")
                    .tooltip("open");
            this.element.val("");
            this.element.change();
            this._delay(function () {
                this.input.tooltip("close").attr("title", "");
            }, 2500);
            this.input.autocomplete("instance").term = "";
        },
        _destroy: function () {
            this.wrapper.remove();
            this.element.show();
        }
    });

})(jQuery);