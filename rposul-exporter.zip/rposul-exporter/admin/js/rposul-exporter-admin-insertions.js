

(function ($) {
    'use strict';
    $(function () {
        $('#insertion_photo').newimageselector({
            placeholder: INSERTIONS_JS.imageplaceholder
        });
    });

})(jQuery);