(function ($) {
    'use strict';
    console.log($('input[name="s"]'));
    $('input[name="s"]').datepicker({dateFormat: ADV_JS.display_date_format});

})(jQuery);