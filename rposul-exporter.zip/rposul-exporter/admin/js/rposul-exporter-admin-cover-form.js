/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

(function ($) {    
    function show_selected_cover_options(template_id, triggerDirty) {
        var speed = $(".cover_form_option:visible").length ? "slow" : null;
        if (speed) {
            $(".cover_form_option:visible").hide("slow");
        }
        $("#template_" + template_id).show(speed);
        var form = $("#template_" + template_id + " form");
        if (triggerDirty || form.hasClass('begin-dirty')){
            form.trigger('dirty.areYouSure');
            form.removeClass('begin-dirty');
            form.addClass("dirty");
        }
    }

    $(document).ready(function () {
        var $submitClicked = false;
        //$("#covermodel").imagepicker();
        $("#covermodel").change(function () {
            show_selected_cover_options($(this).get(0).value, true);
        });
        $("#covermodel").data('orig-value', $("#covermodel").val());
        show_selected_cover_options($("#covermodel").val(), false);

        if ($("#covermodel").length > 0) {
            // we only create this event if the covermodel exists
            $(window).on('beforeunload', function () {
                if (!$submitClicked && $("#covermodel").data('orig-value') !== $("#covermodel").val()) {
                    return "Tipo de capa alterada. Não esqueceu de salvar?";
                }
            });
        }

        $('.upload_image_button').imageselector();

        /*
         * Append inputs to form before sending
         */

        $(".cover_form").submit(function (event) {
            var thisform = this;
            $('<input>').attr({
                type: 'hidden',
                name: $('#covermodel').attr("name"),
                value: $('#covermodel').val()
            }).appendTo(this);
        });
        $(".combobox_titles").combobox();
        $(".button-primary").click(function(){ $submitClicked = true; });
    });

})(jQuery);