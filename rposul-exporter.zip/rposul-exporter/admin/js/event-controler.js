/* global EO_Ajax_Event */

jQuery(document).ready(function ($) {
//Date fields must be wrapped inside event-date

    $.urlParam = function (name) {
        var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(window.location.href);
        if (results === null) {
            return null;
        } else {
            return results[1] || 0;
        }
    };

    eventOrganiserSchedulePicker.init({
        views: {
            start_date: '#eo-start-date',
            occurrence_picker: '#eo-occurrence-datepicker',
            occurrence_picker_toggle: '.eo_occurrence_toggle',
            schedule_last_date: '#eo-schedule-last-date',
            schedule: "#eo-event-recurrence",
            frequency: '#eo-recurrence-frequency',
            week_repeat: '#eo-day-of-week-repeat',
            month_repeat: '#eo-day-of-month-repeat',
            recurrence_section: '.reocurrence_row',
            include: '#eo-occurrence-includes',
            exclude: '#eo-occurrence-excludes',
            schedule_span: '#eo-recurrence-schedule-label', //reads day(s)|week(s)|month(s)|year(s) - depending on schedule selection
            summary: "#eo-event-summary"
        },
        is24hour: Boolean(EO_Ajax_Event.is24hour),
        startday: EO_Ajax_Event.startday,
        schedule: window.eventOrganiserSchedule,
        format: EO_Ajax_Event.format,
        locale: EO_Ajax_Event.locale,
        editable: true //($("#eo-event-recurrence").val() == 'once')//if recurring set to false
    });

    $('#publish-ad').on('click', function () {
        if (window.history.replaceState && $.urlParam('ad') === null && $.urlParam('rposul-reload') === null) {
            var location = window.location.href;
            location += (window.location.href.indexOf('?') !== -1) ? '&' : '?';
            location += 'rposul-reload=true';
            window.history.replaceState(null, null, location);
        }
    });
});