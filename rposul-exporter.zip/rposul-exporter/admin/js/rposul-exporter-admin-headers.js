/* global HEADERS_JS, ajaxurl */

(function ($) {
    'use strict';
    $(function () {


    });

    $('.header_photo').newimageselector({
        placeholder: HEADERS_JS.imageplaceholder
    });

    $('.header_option_type').on('focus', function () {
        $(this).data('previous_value', $(this).children('option:selected').data('show-id'));
    });

    $('.header_option_type').change(function () {
        var previous = $(this).data('previous_value');
        if (previous) {
            $(previous).hide();
        }
        var show_id = $(this).children('option:selected').data('show-id');
        $(show_id).show();
        $(this).data('previous_value', show_id);
    });

    $('select#header_type').change(function () {
        var show_classes = ".show_if_" + $(this).val();

        $('.show_toggle').hide();
        $('.rposul_header_options').hide();
        $(show_classes).show();
        $('.header_option_type:visible').change();

    }).change();

    $('.rposul-input-toggle input[type=checkbox]').on('change', function () {
        var data = {
            'action': 'set_header_enabled',
            'id': $(this).data('id'),
            'value': this.checked
        };
        $.post(ajaxurl, data,
                function (response) {
                    if (!response.success) {
                        alert('A operação falhou.');
                    }
                })
                .fail(function () {
                    alert('A operação falhou.');
                });
    });
    /*
     
     if (data) {
     $.blockUI({message: null});
     $.post(ajaxurl, data,
     function (response) {
     show_page_errors(response);
     })
     .fail(function () {
     alert('Ocorreu um erro ao mover o item. A operação será revertida.');
     innerthis.sortable('cancel');
     })
     .always(function () {
     $.unblockUI();
     });*/

})(jQuery);