<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class TexCoverBorderedImagesFiveNews extends TexBaseCoverTemplate {    

    
    public function generate($page_number) {
        $left_main_post = get_post($this->extra_values['news_first']);
        $right_main_post = get_post($this->extra_values['news_fifth']);
        $side_post = get_post($this->extra_values['news_second']);
        $top_post = get_post($this->extra_values['news_third']);
        $bottom_post = get_post($this->extra_values['news_fourth']);

        $this->auxiliary_data['replace_reference'] = array(
            "news-first" => $this->extra_values['news_first'],
            "news-second" => $this->extra_values['news_second'],
            "news-third" => $this->extra_values['news_third'],
            "news-fourth" => $this->extra_values['news_fourth'],
            "news-fifth" => $this->extra_values['news_fifth']
        );
        
        if (!str_nullorempty($this->extra_values['thumb_primary'])) {
            $left_image_id = $this->extra_values['thumb_primary'];
        } else {
            $left_image_id = get_post_thumbnail_id($left_main_post->ID);
        }
        if (!str_nullorempty($this->extra_values['thumb_secondary'])) {
            $right_image_id = $this->extra_values['thumb_secondary'];
        } else {
            $right_image_id = get_post_thumbnail_id($right_main_post->ID);
        }
        
        $left_image_att = rposul_get_attachment($left_image_id);
        $right_image_att = rposul_get_attachment($right_image_id);        
                
        $left_main_post_content = $this->apply_the_auxiliary_content_text_filter($left_main_post->post_content, 450) . ' \mbox{--news-first--}';
        $right_main_post_content = $this->apply_the_auxiliary_content_text_filter($right_main_post->post_content, 450) . ' \mbox{--news-fifth--}';

        $left_image_basename = $this->add_image_requirement($left_image_att['url']);
        $left_image_sourcename = $this->apply_the_text_filter($left_image_att['credit_to']);
        
        $right_image_basename = $this->add_image_requirement($right_image_att['url']);
        $right_image_sourcename = $this->apply_the_text_filter($right_image_att['credit_to']);
        
        $side_image_att = rposul_get_attachment(get_post_thumbnail_id($side_post->ID));
        $side_image_basename = $this->add_image_requirement($side_image_att['url']);
        $side_image_sourcename = $this->apply_the_text_filter($side_image_att['credit_to']);
        
        $template = sprintf('
\newsavebox{\tbbox}
\newsavebox{\tabox}
\newsavebox{\tcbox}
\savebox{\tabox}{\includelogoandsidenews{%s}{%s}{%s}{%s \mbox{%s}}}

\savebox{\tbbox}{\titlecover{%s}{%s}}

\savebox{\tcbox}{\subtitlecover{%s}{%s}}

\newsavebox{\btestLbox}
\newsavebox{\btestRbox}
\savebox{\btestLbox}{\borderedtext{3mm}{%s}{0.5\textwidth}{%s}{%s}}
\savebox{\btestRbox}{\borderedtext{3mm}{%s}{0.5\textwidth}{%s}{%s}}
\newlength\btestLboxheight
\newlength\btestRboxheight
\newlength\bboxmaxheight
\settototalheight\btestLboxheight{\usebox{\btestLbox}}
\settototalheight\btestRboxheight{\usebox{\btestRbox}}

\ifnum\btestLboxheight>\btestRboxheight
\setlength{\bboxmaxheight}{\btestLboxheight}
\else
\setlength{\bboxmaxheight}{\btestRboxheight}
\fi

\newlength\taboxheight
\newlength\tbboxheight
\newlength\tcboxheight
\settototalheight\taboxheight{\usebox{\tabox}}
\settototalheight\tbboxheight{\usebox{\tbbox}}
\settototalheight\tcboxheight{\usebox{\tcbox}}

\noindent\usebox{\tabox}

\noindent\usebox{\tbbox}

\newlength\resultingimageheight
\setlength{\resultingimageheight}{\dimexpr\textheight-\taboxheight-\tbboxheight-\tcboxheight-\bboxmaxheight\relax}

\borderedimage{3mm}{%s}{0.5\textwidth}{\resultingimageheight}{%s}{%s}%%
\borderedimage{3mm}{%s}{0.5\textwidth}{\resultingimageheight}{%s}{%s}%%
\vspace{-0.5mm}

\borderedtext[\bboxmaxheight]{3mm}{%s}{0.5\textwidth}{%s}{%s}%%
\borderedtext[\bboxmaxheight]{3mm}{%s}{0.5\textwidth}{%s}{%s}

\noindent\usebox{\tcbox}',
                $this->apply_the_text_filter(rposul_ensure_ends_with_dot($side_post->post_title)), $side_image_basename, $side_image_sourcename, $this->apply_the_auxiliary_content_text_filter($side_post->post_content, 420), '--news-second--',
                $this->apply_the_text_filter(rposul_ensure_ends_with_dot($top_post->post_title)), '--news-third--',
                $this->apply_the_text_filter(rposul_ensure_ends_with_dot($bottom_post->post_title)), '--news-fourth--',
                $this->extra_values['color_primary'], $this->apply_the_text_filter(rposul_ensure_ends_with_dot($left_main_post->post_title)), $left_main_post_content,
                $this->extra_values['color_secondary'], $this->apply_the_text_filter(rposul_ensure_ends_with_dot($right_main_post->post_title)), $right_main_post_content,
                $this->extra_values['color_primary'], $left_image_basename, $left_image_sourcename,
                $this->extra_values['color_secondary'], $right_image_basename, $right_image_sourcename,
                $this->extra_values['color_primary'], $this->apply_the_text_filter(rposul_ensure_ends_with_dot($left_main_post->post_title)), $left_main_post_content,
                $this->extra_values['color_secondary'], $this->apply_the_text_filter(rposul_ensure_ends_with_dot($right_main_post->post_title)), $right_main_post_content);        
                
        return $this->apply_the_tex_template_filter($template, $page_number);
    }
}
