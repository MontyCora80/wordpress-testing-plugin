<?php

require_once(plugin_dir_path(__FILE__) . "tex-base-template.php");

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class TexCoverBlankTemplate extends TexBaseCoverTemplate {

    public function generate($page_number) {
        return $this->apply_the_tex_template_filter('\null', $page_number);
    }

}
