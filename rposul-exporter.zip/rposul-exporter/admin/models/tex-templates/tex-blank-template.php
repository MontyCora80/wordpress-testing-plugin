<?php

require_once(plugin_dir_path(__FILE__) . "tex-base-template.php");

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class TexBlankTemplate extends TexBaseTemplate {

    public function can_add_post($post_id) {
        return false;
    }

    public function is_export_ready() {
        $errors = new WP_Error();

        // Advertisement errors
        if (count($this->transient_ads) == 1 && $this->transient_ads[0]->type != 'full') {
            $errors->add('error', 'Anúncios devem ser de página inteira');
        }
        
        return rposul_wp_error_merge(parent::is_export_ready(), $errors);

    }

    public function consume(&$ar_postids) {
        // consume until maxpages are reached
        // the section with blank templates should always contain maxpages
        // this is blocked in the section creation
        return array();
    }

    protected function get_document_class() {
        return '\documentclass{osulblankpage}';
    }

    public function generate($page_number) {
        if (count($this->transient_ads) != 0) {
            $adv = $this->transient_ads[0];
            /* @var $adv Rposul_Advertisement */
            $ad_image = $this->add_image_requirement(rposul_retrieve_adv_image_url($adv));
            if ($adv->type == 'full') {
                $template = '\centerpageadv{' . $ad_image . '}';
            } else {
                $template = '\bottompageadv{' . $ad_image . '}';
            }
        } else {
            $template = '\null';
        }
        return $this->apply_the_tex_template_filter($template, $page_number);
    }

}
