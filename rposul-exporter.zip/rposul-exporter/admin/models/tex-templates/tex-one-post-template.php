<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class TexOnePostTemplate extends TexBaseTemplate {

    const IMAGE_ADJUSTMENT_THRESHOLD = 3200;
    const INCREASE_IMAGE_SIZE_THRESHOLD = 400;
    const ADVERTISEMENT_MAX_ASPECT_RATIO = 1.3;

    
    public function __construct($post_ids, $advertisement_ids, $extra_values) {
        parent::__construct($post_ids, $advertisement_ids, $extra_values);
        $this->limit_post_count = 1;
        $this->limit_post_min_length = 2500;
        $this->limit_post_max_length = 5500;
        $this->limit_page_min_length = $this->limit_post_min_length;
        $this->limit_page_max_length = $this->limit_post_max_length;
    }
    
    protected function get_document_class() {
        return '\documentclass{osulonepage}';
    }

    protected function get_preamble() {
        $post_obj = get_post($this->post_ids[0]);
        $has_ads = count($this->transient_ads) > 0;
        $isFirst = $this->getFirst();

        $pid = $this->post_ids[0];
        $image_att = rposul_get_attachment(get_post_thumbnail_id($pid));
         
        if ($has_ads){
            $ad_image_att = rposul_get_attachment($this->transient_ads[0]->image_id);
            if ($ad_image_att['aspect_ratio'] < self::ADVERTISEMENT_MAX_ASPECT_RATIO){
                $image_att = null;
            }
        }

        if (!$image_att) {
            $image_column_width = 0;
        } else {
            if ($image_att['aspect_ratio'] < 0.6) {
                $image_column_width = 1;
            } else if ($image_att['aspect_ratio'] < 0.8) {
                $image_column_width = 2;
            } else if ($image_att['aspect_ratio'] < 1.8) {
                $image_column_width = 3;
            } else {
                $image_column_width = 4;
            }

            # compensating with the image for text which are too far from goal.
            $postlen = rposul_retrieve_post_content_length($post_obj->ID);           

            if ($has_ads && $image_column_width > 2) {
                $ad_image_att = rposul_get_attachment($this->transient_ads[0]->image_id);
                if ($ad_image_att['aspect_ratio'] < 2.4) {
                    $image_column_width = 2;
                }
            }
            if ($postlen >= self::IMAGE_ADJUSTMENT_THRESHOLD) {
                if ($image_column_width > 2) {
                    $image_column_width = 2;
                }
            }
        }
        
        $preamble = '\savebox{\titlesvbox}{\begin{minipage}{\textwidth}%
\hugetitle{' . $this->apply_the_text_filter(rposul_ensure_ends_with_dot($post_obj->post_title)) . '}%
\end{minipage}}
\settototalheight{\titleheight}{\usebox{\titlesvbox}}

' . (!$has_ads ? '' : ('\newsavebox{\advbottom}
\newlength{\advbottomlength}
\savebox{\advbottom}{\includegraphics[width=\textwidth]{' . $this->add_image_requirement($ad_image_att['url']) . '}}
\settototalheight{\bottomcolumnmargin}{\usebox{\advbottom}}')) . '
    
';
        if ($isFirst) {
            /*$section_obj = new RPOSUL_Section(array('id' => $this->sectionid));
            if ($section_obj->get_headertype() == RPOSUL_HEADERTYPE_ECONOMY) {
                $preamble .= '\instantiateimageheaderframe{economia_header_full.jpg}';
                $this->extra_values['cancelHeaderDisplay'] = true;
            } else if ($section_obj->get_headertype() == RPOSUL_HEADERTYPE_REPORTAGE) {
                $preamble .= '\instantiateimageheaderframe{reportagem.png}';
                $this->extra_values['cancelHeaderDisplay'] = true;
            }*/
        }

        $preamble .= '

' . ($has_ads ? '\instantiateadvertisementbottomframe' : '') . '
\instantiateframestoprightimage{' . $image_column_width . '}

';

        return $preamble;
    }

    /*     * *
     * This function will modify the entry array by removing from it the 
     * consumed posts
     */

    public function consume(&$ar_postids) {
        $ar_info = array();
        $returnPids = array();

        foreach ($ar_postids as $index => $post_obj) {
            $postlen = $post_obj->post_content_length;
            if ($postlen > $this->limit_post_min_length && $postlen < $this->limit_post_max_length) {
                $returnPids[] = $post_obj->ID;
                $ar_info[] = array(
                    "index" => $index,
                    "pid" => $post_obj->ID,
                    "length" => $postlen);
                break;
            }
        }

        if (count($ar_info) > 0) {
            foreach ($ar_info as $val) {
                unset($ar_postids[$val['index']]);
            }
            $this->post_ids = $returnPids;
            return $returnPids;
        } else {
            $this->post_ids = array();
            return null;
        }
    }

    protected function generate($page_number) {
        $isFirst = $this->getFirst();
        $has_ads = count($this->transient_ads) > 0;

        if ($isFirst) {
            $template = '
\begin{staticcontents*}{imageheader}
\usebox{\imageheadersvbox}
\end{staticcontents*}';
        } else {
            $template = "";
        }

        $pid = $this->post_ids[0];
        $content_post = get_post($pid);
        $content = $this->apply_the_content_filter($content_post);
        $image_att = rposul_get_attachment(get_post_thumbnail_id($pid));
        if ($has_ads){
            $ad_image_att = rposul_get_attachment($this->transient_ads[0]->image_id);
            if ($ad_image_att['aspect_ratio'] < self::ADVERTISEMENT_MAX_ASPECT_RATIO){
                $image_att = null;
            }
        }
        if ($image_att) {
            $imagename = $this->add_image_requirement($image_att['url']);
            $sourcename = $this->apply_the_text_filter($image_att['credit_to']);
            $caption = $this->apply_the_text_filter($image_att['caption']);
        }
        $template .= '
\begin{staticcontents*}{titlestatic}
\usebox{\titlesvbox}
\end{staticcontents*}

' . (!$has_ads ? '' : '
\begin{staticcontents*}{advertisementframe}
\usebox{\advbottom}
\end{staticcontents*}');
        
        if ($image_att) {
            $template .= '

\begin{staticcontents*}{widecolumn}
\ClipImage{\imagewidth}{\imageheight}{' . $imagename . '}{' . $sourcename . '}{' . $caption . '}
\end{staticcontents*}';
        }
        $template .= "
            
$content";

        return $this->apply_the_tex_template_filter($template, $page_number);
    }

}
