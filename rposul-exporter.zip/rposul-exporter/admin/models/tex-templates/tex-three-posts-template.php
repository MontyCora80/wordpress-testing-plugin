<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class TexThreePostsTemplate extends TexTwoPostsTemplate {

    public function __construct($post_ids, $advertisement_ids, $extra_values) {
        parent::__construct($post_ids, $advertisement_ids, $extra_values);
        $this->limit_post_count = 3;
        $this->limit_post_min_length = 700;
        $this->limit_post_max_length = 1000;
        $this->IMAGE_ADJUSTMENT_THRESHOLD = 850; // threshold to allow max 2 column image
        $this->limit_page_min_length = 1600;
        $this->limit_page_max_length = 2500;
        $this->INCREASE_IMAGE_SIZE_THRESHOLD = 50;
    }

    protected function get_document_class() {
        return '\documentclass{osulthreenews}';
    }

    protected function get_image_column_width($image_att, $postlen) {
        if ($image_att['aspect_ratio'] < 2) {
            $image_column_width = 1;
        } else if ($image_att['aspect_ratio'] < 2.3) {
            $image_column_width = 2;
        } else {
            $image_column_width = 3;
        }

        # compensating with the image for text which are too far from goal.
        if ($postlen > $this->limit_post_max_length - $this->INCREASE_IMAGE_SIZE_THRESHOLD && $image_column_width > 1) {
            $image_column_width--;
        } else if ($postlen < $this->limit_post_min_length + $this->INCREASE_IMAGE_SIZE_THRESHOLD && $image_column_width < 2) {
            $image_column_width++;
        }

        return $image_column_width;
    }

    protected function doOneSelection($ar_info) {
        $ar_info_count = count($ar_info);
        for ($i = 0; $i < $ar_info_count - 2; $i ++) {
            $j = $i + 1; // Start right after i.
            $k = $ar_info_count - 1; // Start at the end of the array.
            while ($k >= $j) {
                // We got a match! All done.
                $value_sum = $ar_info[$i]["length"] + $ar_info[$j]["length"] + $ar_info[$k]["length"];
                if ($value_sum > $this->limit_page_min_length && $value_sum < $this->limit_page_max_length) {
                    return array($i, $j, $k);
                }

                $value_sum ? $k-- : $j++;
            }
        }
        // found nothing
        return null;
    }

}
