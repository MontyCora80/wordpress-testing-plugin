<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class TexCoverSimpleFourNews extends TexBaseCoverTemplate {
    
    protected function get_cover_image_tex(){        
        if (!str_nullorempty($this->extra_values['thumb_primary'])) {
            $main_image_id = $this->extra_values['thumb_primary'];
        } else {
            $main_post = get_post($this->extra_values['news_first']);
            $main_image_id = get_post_thumbnail_id($main_post->ID);
        }
        
        $main_image_att = rposul_get_attachment($main_image_id);
        
        $main_image_basename = $this->add_image_requirement($main_image_att['url']);
        $sourcename = $this->apply_the_text_filter($main_image_att['credit_to']);
        return '\ClipImage{\linewidth}{\resultingimageheight}{' . $main_image_basename . "}{" . $sourcename . "}{}";
    }

    public function generate($page_number) {
        $main_post = get_post($this->extra_values['news_first']);
        $side_post = get_post($this->extra_values['news_second']);
        $top_post = get_post($this->extra_values['news_third']);
        $bottom_post = get_post($this->extra_values['news_fourth']);

        // TODO quando colocar tags na geração da capa, colocar como %news_first% etc para substituicao pelo python
        // utilizando a busca pelos posts ids tambem adicionados no auxiliary data
        $this->auxiliary_data['replace_reference'] = array(
            "news-first" => $this->extra_values['news_first'],
            "news-second" => $this->extra_values['news_second'],
            "news-third" => $this->extra_values['news_third'],
            "news-fourth" => $this->extra_values['news_fourth']
        );

        $side_image_att = rposul_get_attachment(get_post_thumbnail_id($side_post->ID));
        $side_image_basename = $this->add_image_requirement($side_image_att['url']);
        $side_image_sourcename = $side_image_att['credit_to'];
        
        $template = sprintf('
\newsavebox{\tbbox}
\newsavebox{\tabox}
\newsavebox{\tcbox}
\newsavebox{\tdbox}
\savebox{\tabox}{\includelogoandsidenews{%s}{%s}{%s}{%s \mbox{%s}}}

\savebox{\tbbox}{\titlecover{%s}{%s}}

\savebox{\tdbox}{\smallnewscover{%s}{%s \mbox{%s}}}

\savebox{\tcbox}{\subtitlecover{%s}{%s}}

\newlength\taboxheight
\newlength\tbboxheight
\newlength\tcboxheight
\newlength\tdboxheight
\settototalheight\taboxheight{\usebox{\tabox}}
\settototalheight\tbboxheight{\usebox{\tbbox}}
\settototalheight\tcboxheight{\usebox{\tcbox}}
\settototalheight\tdboxheight{\usebox{\tdbox}}

\noindent\usebox{\tabox}

\noindent\usebox{\tbbox}

\newlength\resultingimageheight
\setlength{\resultingimageheight}{\dimexpr\textheight-\taboxheight-\tbboxheight-\tdboxheight-\tcboxheight\relax}

%s

\noindent\usebox{\tdbox}
\noindent\usebox{\tcbox}',
                $this->apply_the_text_filter(rposul_ensure_ends_with_dot($side_post->post_title)), $side_image_basename, $side_image_sourcename, $this->apply_the_auxiliary_content_text_filter($side_post->post_content, 420), '--news-second--',
                $this->apply_the_text_filter(rposul_ensure_ends_with_dot($top_post->post_title)), '--news-third--',
                $this->apply_the_text_filter(rposul_ensure_ends_with_dot($main_post->post_title)), $this->apply_the_auxiliary_content_text_filter($main_post->post_content, 450), '--news-first--',
                $this->apply_the_text_filter(rposul_ensure_ends_with_dot($bottom_post->post_title)), '--news-fourth--',
                $this->get_cover_image_tex());
                
                
        return $this->apply_the_tex_template_filter($template, $page_number);
    }
}
