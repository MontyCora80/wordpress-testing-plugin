<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class TexCoverBorderedImagesFourNews extends TexCoverSimpleFourNews {

    protected function get_cover_image_tex() {
        $main_post = get_post($this->extra_values['news_first']);
        $backup_image_id = get_post_thumbnail_id($main_post->ID);
        
        if (!str_nullorempty($this->extra_values['thumb_primary'])) {
            $left_image_id = $this->extra_values['thumb_primary'];
        } else {
            $left_image_id = $backup_image_id;
        }
        if (!str_nullorempty($this->extra_values['thumb_secondary'])) {
            $right_image_id = $this->extra_values['thumb_secondary'];
        } else {
            $right_image_id = $backup_image_id;
        }
        
        $left_image_att = rposul_get_attachment($left_image_id);
        $right_image_att = rposul_get_attachment($right_image_id);    
        
        $left_image_basename = $this->add_image_requirement($left_image_att['url']);
        $left_image_sourcename = $this->apply_the_text_filter($left_image_att['credit_to']);
        $right_image_basename = $this->add_image_requirement($right_image_att['url']);
        $right_image_sourcename = $this->apply_the_text_filter($right_image_att['credit_to']);
        
        return '\borderedimage{3mm}{' . arr_get($this->extra_values, 'color_primary', 'gremio') . '}{0.5\textwidth}{\resultingimageheight}{' . $left_image_basename . '}{' . $left_image_sourcename . '}%' . "\n"
                . '\borderedimage{3mm}{' . arr_get($this->extra_values, 'color_secondary', 'inter') . '}{0.5\textwidth}{\resultingimageheight}{' . $right_image_basename . '}{' . $right_image_sourcename . '}%' . "\n"
                . '\vspace{-0.5mm}';
    }

}
