<?php

require_once(plugin_dir_path(__FILE__) . "tex-base-template.php");

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

abstract class TexBaseCoverTemplate extends TexBaseTemplate {

    public function __construct($cover_options, $post_ids = array()) {
        parent::__construct($post_ids, array(), $cover_options);
    }

    public function can_add_post($post_id) {
        return false;
    }

    public function is_export_ready() {
        return true;
    }

    public function consume(&$ar_postids) {
        // This is a special type of post that doesnt consume posts, they 
        // are directly available in the database options
        return;
    }

    protected function get_document_class() {
        return '\documentclass{osulcover}';
    }

    public function export($page_number) {
        $this->auxiliary_data['is_cover'] = true;
        parent::export($page_number);
    }

    protected function get_header($page_number) {
        $current_date = RPOSUL_Options::get_option(RPOSUL_OPTION_NEWSPAPER_DATE);
        $date_string = $this->get_date_string();        
        $year_string = rposul_get_newspaper_year_from_date($current_date);
        $newspaper_number = rposul_get_news_number_from_date($current_date);
        return '\headercover{' . $newspaper_number . '}{' . $page_number . '}{' . $date_string . '}{' . $year_string . '}';
    }

    protected function apply_the_auxiliary_content_text_filter($content, $max_length, $min_length = 250) {

        $paragraphs = array_filter(preg_split("/\r\n|\n|\r/", $this->apply_the_text_filter($content)));

        $acceptable_loss = $max_length - $min_length;
        $consideredText = "";
        foreach ($paragraphs as $p) {
            if (mb_strlen($consideredText) < $max_length - $acceptable_loss) {
                $consideredText .= $p;
            } else {
                break;
            }
        }

        if (mb_strlen($consideredText) > $max_length) {
            $consideredText = mb_substr($consideredText, 0, $max_length);
            $partial_sentencestrrchr = strrchr($consideredText, ".");
            if (mb_strlen($partial_sentencestrrchr) <= $acceptable_loss) {
                //We consider fine to cut this portion of the string for the sake of design
                $consideredText = str_replace($partial_sentencestrrchr, '.', $consideredText);
            } else {
                $partial_sentencestrrchr = strrchr($consideredText, " ");
                //Issue #1030
                if ($partial_sentencestrrchr == " ") {
                    // The last letter of $consideredText is a space, so
                    // We could not retrieve the last word without removing the last space.
                    $partial_sentencestrrchr = strrchr(mb_substr($consideredText, 0, mb_strlen($consideredText) - 1), " ");
                }
                $consideredText = str_replace($partial_sentencestrrchr, '', $consideredText) . ' ...';
            }
        }

        return $consideredText;
    }

    protected function get_date_string($full_string_format = false) {
        return parent::get_date_string(true);
    }

}
