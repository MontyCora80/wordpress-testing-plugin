<?php

require_once(plugin_dir_path(__FILE__) . "tex-base-template.php");

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class TexColumnistsTemplate extends TexBaseTemplate
{

    const TEXT_COLOR = "weakred";

    public function __construct($post_ids, $advertisement_ids, $extra_values)
    {
        parent::__construct($post_ids, $advertisement_ids, $extra_values);
        $this->limit_post_count = 1;
        $this->limit_page_min_length = 700;
        $this->limit_post_min_length = $this->limit_page_min_length;
    }

    /*     * *
     * This function will modify the entry array by removing from it the 
     * consumed posts
     */

    public function consume(&$ar_postids)
    {
        $ar_info = array();
        $returnPids = array();
        foreach ($ar_postids as $index => $post_obj) {
            $postlen = $post_obj->post_content_length;
            if ($postlen > $this->limit_post_min_length) {
                $returnPids[] = $post_obj->ID;
                $ar_info[] = array(
                    "index" => $index,
                    "pid" => $post_obj->ID,
                    "length" => $postlen
                );

                break;
            }
        }
        if (count($ar_info) > 0) {
            foreach ($ar_info as $val) {
                unset($ar_postids[$val['index']]);
            }
            $this->post_ids = $returnPids;
            return $returnPids;
        } else {
            $this->post_ids = array();
            return null;
        }
    }

    protected function get_document_class()
    {
        return '\documentclass{osulcolunistastex}';
    }

    private function get_columnists_info($pid)
    { }

    protected function generate($page_number)
    {
        $title = array();
        $template = "";

        foreach ($this->post_ids as $pid) {
            $content_post = get_post($pid);
            $author_id = $content_post->post_author;

            $author_name = get_the_author_meta('display_name', $author_id);
            $image_id = get_user_meta($author_id, 'foto_de_perfil', true); 
            $author_mail = get_user_meta($author_id, 'nota_de_rodape', true);

            $author_image = '';
            $attach_info = rposul_get_attachment($image_id);
            if ($attach_info) {
                $author_image = $this->add_image_requirement($attach_info['url']);
            }
                
            /*if (!$authorname) {
                $avatar_url = get_avatar_url($author_id, array('default' => '404'));
                $authorimage = $this->add_image_requirement($avatar_url);                
            }*/

            $title = $this->apply_the_text_filter(mb_strtoupper($content_post->post_title));
            $content = $this->apply_the_content_filter($content_post);
            $template = '\def\footnotebottommargin{.3cm}
\newsavebox{\topbox}
\newsavebox{\titlebox}
\newsavebox{\footnotebox}
\newsavebox{\multicolsbox}
\savebox{\topbox}{\includeheaderimage}%
\savebox{\titlebox}{\includeauthorandtitle{' . $author_image . '}{' . $author_name . '}{' . $title . '}}%
\savebox{\footnotebox}{\footnotesize{}' . $author_mail . '}%

\newlength{\advertisementheight}
\setlength{\advertisementheight}{0pt}' . (!empty($this->transient_ads) ? '
    
\newbox{\advertisementbox}
\savebox{\advertisementbox}{\includegraphics[width=\textwidth]{' . $this->add_image_requirement(rposul_retrieve_adv_image_url($this->transient_ads[0])) . '}}
\settototalheight{\advertisementheight}{\usebox{\advertisementbox}}' : '')
                . '
\newlength\topboxheight
\newlength\titleboxheight
\settototalheight\topboxheight{\usebox{\topbox}}
\settototalheight\titleboxheight{\usebox{\titlebox}}

\noindent\usebox{\topbox}
\begin{envrightborder}
\noindent\usebox{\titlebox}
\end{envrightborder}

\newlength\resultingminipageheight
\setlength{\resultingminipageheight}{\dimexpr\textheight-\topboxheight-\titleboxheight-\advertisementheight-1.5cm\relax}

\begin{envnotopborder}
\parbox[t][\resultingminipageheight]{\textwidth} {

\begin{multicols}{2}
' . $content . '
\end{multicols}
\vfill\hfill\usebox{\footnotebox}\vspace{\footnotebottommargin}
}
\ifnum\parboxbadness=1000000\relax%
%passed maximum size
\PackageInfo{\packageName}{I002: 1}
\else
%bellow maximum size
\PackageInfo{\packageName}{I002: 0}
\fi
\end{envnotopborder}
' . (!empty($this->transient_ads) ? '\usebox{\advertisementbox}' : '');
        }

        return $this->apply_the_tex_template_filter($template, $page_number);
    }

    function apply_the_content_filter($wp_post)
    {
        $content = $wp_post->post_content;
        $filteredContent = parent::apply_the_content_filter($content);
        $filteredContent = preg_replace('/\\\\lettrine{(.*?)}{(.*?)} /', '\\noindent\\textbf{\\textcolor{' . TexColumnistsTemplate::TEXT_COLOR . '}{$1}}$2 ', $filteredContent);
        $filteredContent = str_replace("\spacestub ", " ", $filteredContent);
        return $filteredContent;
    }
}
