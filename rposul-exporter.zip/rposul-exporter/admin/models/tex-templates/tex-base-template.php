<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

abstract class TexBaseTemplate {

    protected $post_ids;
    protected $extra_values;
    protected $transient_ads;
    protected $limit_post_count;
    protected $limit_post_min_length;
    protected $limit_post_max_length;
    protected $limit_page_min_length;
    protected $limit_page_max_length;

    protected abstract function generate($page_number);

    protected $auxiliary_data = array('images' => array());

    /**
     * Adds an image url to the requirement of image files for this page. 
     * The returned value should be used in the output as the filename
     * 
     * @param String $url The image url
     * @return String the filename to be used
     */
    public function __construct($post_ids, $advertisement_ids, $extra_values) {
        $this->post_ids = $post_ids;
        $this->extra_values = $extra_values;
        if ($advertisement_ids) {
            $implode_ids = implode(',', $advertisement_ids);
            $this->transient_ads = Rposul_Advertisement::get(array('WHERE' => "id IN ($implode_ids)"));
        } else {
            $this->transient_ads = array();
        }

        $insertion_id = arr_get($extra_values, 'insertion_id');
        if ($insertion_id) {
            $insertions = Rposul_Insertion::get(array("WHERE" => "id=$insertion_id"));
            $insertion = $insertions[0];
            /* @var $insertion Rposul_Insertion */
            $insertion_as_ad = new Rposul_Advertisement();
            $insertion_as_ad->title = $insertion->name;
            $insertion_as_ad->type = 'full';
            $insertion_as_ad->page = $insertion->page;
            $insertion_as_ad->image_id = $insertion->attachment_id;
            $this->transient_ads[] = $insertion_as_ad;
        }
    }

    public function is_export_ready() {
        $errors = new WP_Error();

        // Advertisement errors
        if (count($this->transient_ads) > 0) {
            if (count($this->transient_ads) > 1) {
                $errors->add('error', 'Somente um anúncio por página é permitido.');
            }

            if (count($this->post_ids) > 0) {
                foreach ($this->transient_ads as $ad) {
                    if ($ad->type === 'full') {
                        $errors->add('error', 'Anúncios de página inteira não podem ser acompanhados por posts.');
                        break;
                    }
                }
            }
        }

        if (!empty($this->limit_post_count) && $this->limit_post_count != count($this->post_ids)) {
            $errors->add('error', 'Número de posts deveria ser ' . $this->limit_post_count . '.');
        }

        if (!empty($this->limit_page_min_length) || !empty($this->limit_page_max_length) ||
                !empty($this->limit_post_min_length) || !empty($this->limit_post_max_length)) {
            $page_length = 0;
            foreach ($this->post_ids as $pid) {
                $postlen = rposul_retrieve_post_content_length($pid);
                if (!empty($this->limit_post_min_length) && $postlen < $this->limit_post_min_length) {
                    $errors->add('warning', "Tamanho mínimo para o post (recomendado): $this->limit_post_min_length.");
                }
                if (!empty($this->limit_post_max_length) && $postlen > $this->limit_post_max_length) {
                    $errors->add('warning', "Tamanho máximo para o post (recomendado): $this->limit_post_max_length.");
                }
                $page_length += $postlen;
            }

            if (!empty($this->limit_page_min_length) && $page_length < $this->limit_page_min_length) {
                $errors->add('warning', "Tamanho mínimo para a página (recomendado): $this->limit_post_min_length.");
            }
            if (!empty($this->limit_page_max_length) && $page_length > $this->limit_page_max_length) {
                $errors->add('warning', "Tamanho máximo para a página (recomendado): $this->limit_post_max_length.");
            }
        }

        return !empty($errors->get_error_codes()) ? $errors : true;
    }

    protected function add_image_requirement($url) {
        if (empty($url)) {
            return "";
        } else {
            $filebasename = clean_filename_string(basename($url));
            $this->auxiliary_data['images'][] = array("url" => $url, "outputname" => $filebasename);
            return $filebasename;
        }
    }

    protected function getFirst() {
        if (array_key_exists("isFirst", $this->extra_values)) {
            $isFirst = $this->extra_values['isFirst'];
        } else {
            $isFirst = false;
        }
        return $isFirst;
    }

    public function setFirst($isFirst) {
        $this->extra_values['isFirst'] = $isFirst;
    }

    public function export($page_number) {
        $this->post_ids = array_values($this->post_ids);

        $content = $this->generate($page_number);

        if ($content) {
            $this->auxiliary_data['page'] = $page_number;
            $this->auxiliary_data['posts'] = $this->post_ids;
            return Rposul_Exporter_PyExporterComm::add_page("page-$page_number", $content, json_encode($this->auxiliary_data));
        }
        return true;
    }

    protected function apply_the_text_filter($content) {
        // chr 194 chr 160 represents non breaking space issue #720
        $latex_ready_content = str_replace(
                array(
            '&', '$', '%', '#', chr(194) . chr(160)
                ), array(
            '\&', '\$', '\%', '\#', ' '
                ), rposul_html_decode($content)
        );
        $www_corrected_content = preg_replace("/\b((?:https?:\/\/|www\.).+?\.[\w\d]+(?:\.[\w\d]+)*.*?)(\.?)(\s|\}|$|]|\))/mi", '\url{$1}$2$3', $latex_ready_content);
        $mail_corrected_content = preg_replace("/\b([\w.-]+@[\w.-]+\.[A-Za-z]{2,6})\b/mi", '\url{$1}', $www_corrected_content);

        return $mail_corrected_content;
    }

    /*     * *
     * Retorna o conteúdo de um post filtrado
     * $wp_post pode ser uma string ou um post wordpress
     * Caso seja um post apenas seu atributo post_content deve ser utilzado
     */

    protected function apply_the_content_filter($wp_post) {
        if (is_string($wp_post)) {
            $content = $wp_post;
        } else {
            $content = $wp_post->post_content;
        }
        $linestartreg = "(?><\/em>|<\/p>|<p.*?>|<br>|<br\/>|^)(?>\s*<span.*?>)*\s*";
        $lineendreg = "\s*(?><\/span>\s*?)*\s*?(?><\/p>|<br>|<br\/>|$)";


        $b_replaced_content = preg_replace("/$linestartreg<b>(.*?)<\/b>$lineendreg/m", "\n" . '\shorttitleitem{$1}' . "\n", $content);
        $strong_replaced_content = preg_replace("/$linestartreg<strong>(.*?)<\/strong>$lineendreg/m", "\n" . '\shorttitleitem{$1}' . "\n", $b_replaced_content);
        $u_replaced_content = preg_replace("/$linestartreg<u>(.*?)<\/u>$lineendreg/m", "\n" . '\shorttitleitem{$1}' . "\n", $strong_replaced_content);
        $span_replaced_content = preg_replace("/$linestartreg<span.*?underline.*?>(.*?)<\/span>$lineendreg/m", "\n" . '\shorttitleitem{$1}' . "\n", $u_replaced_content);
        $itemize_replaced_content = preg_replace("/$linestartreg\*\s*(.*?)$lineendreg/m", '\begin{itemize}\item $1\end{itemize}' . "\n", $span_replaced_content);
        $iframe_corrected_content = preg_replace("/<iframe.*src=['\"](.*?)youtube(.*?)embed\/(.*?)(?:\?.*)?['\"].*>.*?<\/iframe>/m", "www.youtube.com/$3", $itemize_replaced_content);

        $latex_ready_content = $this->apply_the_text_filter($iframe_corrected_content);
        if ($latex_ready_content[0] != '\\') {
            $second_letter = 1;
            $lettrine_letter = mb_substr($latex_ready_content, 0, $second_letter);
            $space_index = mb_strpos($latex_ready_content, ' ', $second_letter);
            if ($space_index === $second_letter) {
                $space_index = mb_strpos($latex_ready_content, ' ', $second_letter + 1);
                $lettrine_letter_content = str_replace(" ", "\spacestub ", mb_substr($latex_ready_content, $second_letter, $space_index - 1));
            } else {
                $lettrine_letter_content = mb_substr($latex_ready_content, $second_letter, $space_index - 1);
            }
            $text_content = mb_substr($latex_ready_content, $space_index + 1);
            $latex_ready_content = "\lettrine{{$lettrine_letter}}{{$lettrine_letter_content}} $text_content";
            //$latex_ready_content = '\lettrine{' . mb_substr($latex_ready_content, 0, 1) . '}{} ' . mb_substr($latex_ready_content, 1);
        }

        return $latex_ready_content;
    }

    protected function get_document_class() {
        return '\documentclass[10pt,final,hyphenatedtitles]{papertex2}';
    }

    protected function get_preamble() {
        return '';
    }

    /* protected function get_date_string() {
      $db_date = new DateTime(RPOSUL_Options::get_option(RPOSUL_OPTION_NEWSPAPER_DATE));
      setlocale(LC_TIME, "pt_BR", "pt_BR.iso-8859-1", "pt_BR.utf-8", "portuguese");
      date_default_timezone_set('America/Sao_Paulo');
      return utf8_encode(strftime("%A, %d de %B de %Y", $db_date->getTimestamp()));
      } */

    /**
     * Return the newspaper datestring
     * 
     * @param type $full_string_format Only used when the OPTION_DOUBLE_NEWS_DATE is set. When this is false, if both days on the 
     * newspaper are in the same month then the first date string will be only the day, without the month and year so we do not repeat this data.
     * If this value is true then the string will always be on the format "%A/%A, %d de %B de %Y e %d de %B de %Y", even if the months of the two 
     * dates are the same. This option was created because on the cover we need always the full string. Default: False
     * @return str The date string
     */
    protected function get_date_string($full_string_format = false) {
        $db_date = new DateTime(RPOSUL_Options::get_option(RPOSUL_OPTION_NEWSPAPER_DATE));
        // Setlocale not working on pampa server. Really ugly workaround
        setlocale(LC_ALL, "pt_BR", "pt_BR.iso-8859-1", "pt_BR.utf-8", "pt_BR.iso88591", "pt_BR.utf8", "portuguese");
        date_default_timezone_set('America/Sao_Paulo');

        if (!RPOSUL_Options::get_option(RPOSUL_OPTION_DOUBLE_NEWS_DATE, false)) {
            $full_date_string = utf8_encode(strftime("%A, %d de %B de %Y", $db_date->getTimestamp()));
        } else {
            $following_date = new DateTime(RPOSUL_Options::get_option(RPOSUL_OPTION_NEWSPAPER_DATE));
            $following_date->modify("+1 day");

            $weekdayA = utf8_encode(strftime("%A", $db_date->getTimestamp()));
            $weekdayB = utf8_encode(strftime("%A", $following_date->getTimestamp()));
            
            if (!$full_string_format) {
                $monthA = utf8_encode(strftime("%B", $db_date->getTimestamp()));
                $monthB = utf8_encode(strftime("%B", $following_date->getTimestamp()));
                
                if (strcmp($monthA, $monthB) == 0) {
                    $partial_date_stringA = utf8_encode(strftime("%d", $db_date->getTimestamp()));
                } else {
                    $partial_date_stringA = utf8_encode(strftime("%d de %B de %Y", $db_date->getTimestamp()));
                }
                
            } else {
                $partial_date_stringA = utf8_encode(strftime("%d de %B de %Y", $db_date->getTimestamp()));
            }

            $partial_date_stringB = utf8_encode(strftime("%d de %B de %Y", $following_date->getTimestamp()));
            $full_date_string = "{$weekdayA} / {$weekdayB}, {$partial_date_stringA} e {$partial_date_stringB}";
        }

        //Replace is made mostly to correct ucwords which we dont want to capitalize
        // '/' char is separated by spaces inside the string so we can capitalize the second word. we then remove the space
        $full_date_string_capital = str_replace(array(' De ', ' E ', ' / '), array(' de ', ' e ', '/'), ucwords($full_date_string));

        // Language corrections when server is not correctly configured
        $pt_weekday_full_date_string = str_replace(array("Sunday", 'Monday', 'Tuesday', "Wednesday", "Thursday", "Friday", "Saturday"), array("Domingo", "Segunda-feira", "Terça-feira", "Quarta-feira", "Quinta-feira", "Sexta-feira", "Sábado"), $full_date_string_capital);
        return str_replace(array("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"), array("Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"), $pt_weekday_full_date_string);
    }

    protected function get_header($page_number) {

        $headers = Rposul_Header::get(array('WHERE' => 'id=' . arr_get($this->extra_values, 'header_type', 0)));
        // fallback to default header when none is selected
        if (empty($headers)) {
            $default_header = Rposul_Options::get_option(RPOSUL_OPTION_DEFAULT_HEADER);
            if (!empty($default_header)) {
                $headers = Rposul_Header::get(array('WHERE' => "id=$default_header"));
            }
        }

        if (!empty($headers) && !empty($headers[0]->content)) {
            $header = $headers[0];
            /* @var $header Rposul_Header */
            $headrule = $header->headrule_enabled ? 'y' : '';

            $contentA = '';
            if (isset($header->content[0]['type']) && $header->content[0]['type'] == 'text') {

                $contentA = $this->replace_header_text($page_number, $header->content[0]['value']);
            } else {
                $image_att = rposul_get_attachment($header->content[0]['value']);
                if ($image_att) {
                    $contentA = $this->add_image_requirement($image_att['url']);
                    if (count($header->content) == 1) {
                        $contentA = "\headerimagecontent[1]{{$contentA}}";
                    } else {
                        $contentA = "\headerimagecontent{{$contentA}}";
                    }
                }
            }

            $contentB = '';
            if (count($header->content) > 1) {
                if (isset($header->content[1]['type']) && $header->content[1]['type'] == 'text') {
                    $contentB = $this->replace_header_text($page_number, $header->content[1]['value']);
                } else {
                    $image_att = rposul_get_attachment($header->content[1]['value']);
                    if ($image_att) {
                        $contentB = "\headerimagecontent{{$this->add_image_requirement($image_att['url'])}}";
                    }
                }
            }

            return '
\newsavebox{\headersideA}
\newsavebox{\headersideB}
\savebox{\headersideA}{' . $contentA . '}
\savebox{\headersideB}{' . $contentB . '}
\headercustom[' . $headrule . ']{\usebox{\headersideA}}{\usebox{\headersideB}}{' . $page_number . '}';
        }
        return "";
    }

    protected function replace_header_text($page_number, $text) {
        $datestring = $this->get_date_string();
        $mod_text = $this->apply_the_text_filter(str_replace(
                        array('{{date}}', '{{page}}'), array($datestring, $page_number), $text
        ));

        $regex_mod_text = preg_replace(
                array(
            "/{{\s*bold\s*}\s*(.*?)\s*}/i",
            "/{{\s*tiny\s*}\s*(.*?)\s*}/i",
            "/{{\s*thin\s*}\s*(.*?)\s*}/i",
                ), array(
            '\textbf{$1}',
            '{\tiny $1}',
            '\$$1\$'
                ), $mod_text);
        return "\headertextcontent{{$regex_mod_text}}";
    }

    protected function apply_the_tex_template_filter($content, $page_number) {
        $header = $this->get_document_class() . "\n";
        if (!arr_get($this->extra_values, 'cancelHeaderDisplay', false)) {
            $header .= "{$this->get_header($page_number)}\n";
        }
        $header .= $this->get_preamble();
        $header .= '
\begin{document}
';
        $footer = "\n" . '\end{document}' . "\n";

        return $header . $content . $footer;
    }

}
