<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class TexFourPostsTemplate extends TexBaseTemplate {


    public function __construct($post_ids, $advertisement_ids, $extra_values) {
        parent::__construct($post_ids, $advertisement_ids, $extra_values);
        $this->limit_post_count = 4;
        $this->limit_post_min_length = 650;
        $this->limit_post_max_length = 710;
        $this->limit_page_min_length = 2600;
        $this->limit_page_max_length = 2840;
    }


    public function get_varname_for_post_index($index, $prefix = "", $suffix = "") {
        return $prefix . chr(65 + $index) . $suffix;
    }

    protected function get_document_class() {
        return '\documentclass{osulfournewssquare}';
    }

    /*     * *
     * This function will modify the entry array by removing from it the 
     * consumed posts
     */

    protected function doOneSelection($ar_info) {
        $ar_info_count = count($ar_info);
        $value_sum = 0;
        $return_array = null;
        for ($i = 0; $i < $ar_info_count - 1; $i ++) {
            for ($j = $i + 1; $j < $ar_info_count; $j++) {
                if (abs($ar_info[$i]["length"] - $ar_info[$j]["length"]) < 50) {
                    $value_sum = $ar_info[$i]["length"] + $ar_info[$j]["length"];
                    $return_array = array($i, $j);
                    break;
                }
            }
            if ($value_sum != 0) {
                break;
            }
        }
        if ($value_sum == 0) {
            return null;
        }

        for ($i = 0; $i < $ar_info_count - 1; $i ++) {
            if (in_array($i, $return_array)) {
                continue;
            }
            for ($j = $i + 1; $j < $ar_info_count; $j++) {
                if (in_array($j, $return_array)) {
                    continue;
                }
                if (abs($ar_info[$i]["length"] - $ar_info[$j]["length"]) < 50) {
                    $temp_value_sum = $value_sum + $ar_info[$i]["length"] + $ar_info[$j]["length"];
                    if ($temp_value_sum > $this->limit_page_min_length && $temp_value_sum < $this->limit_page_max_length) {
                        $return_array[] = $i;
                        $return_array[] = $j;
                        return $return_array;
                    }
                }
            }
        }
        // found nothing
        return null;
    }

    public function consume(&$ar_postids) {
        $ar_info = array();
        foreach ($ar_postids as $index => $post_obj) {
            $postlen = $post_obj->post_content_length;
            if ($postlen > $this->limit_post_min_length && $postlen < $this->limit_post_max_length) {
                $ar_info[] = array(
                    "index" => $index,
                    "pid" => $post_obj->ID,
                    "length" => $postlen);
            }
        }
        $retValues = $this->doOneSelection($ar_info);
        if (isset($retValues)) {
            foreach ($retValues as $val) {
                unset($ar_postids[$ar_info[$val]['index']]);
            }
            $returnPids = array();
            foreach ($retValues as $val) {
                $returnPids[] = $ar_info[$val]['pid'];
            }
            $this->post_ids = $returnPids;
            return $returnPids;
        } else {
            $this->post_ids = array();
            return null;
        }
    }

    protected function generate($page_number) {
        $template = "";


        for ($index = 0; $index < count($this->post_ids); $index = $index + 2) {
            if ($index + 1 >= count($this->post_ids)) {
                continue;
            }

            if ($index != 0) {
                $template .= '
\vspace{\imagesep}
\hrule
\vspace*{\imagesep}
';
            }

            $left_pid = $this->post_ids[$index];
            $left_post_obj = get_post($left_pid);
            $left_post_title = $this->apply_the_text_filter(rposul_ensure_ends_with_dot($left_post_obj->post_title));
            $left_post_content = $this->apply_the_content_filter($left_post_obj);
            $left_post_image_att = rposul_get_attachment(get_post_thumbnail_id($left_pid));



            $right_pid = $this->post_ids[$index + 1];
            $right_post_obj = get_post($right_pid);
            $right_post_title = $this->apply_the_text_filter(rposul_ensure_ends_with_dot($right_post_obj->post_title));
            $right_post_content = $this->apply_the_content_filter($right_post_obj);
            $right_post_image_att = rposul_get_attachment(get_post_thumbnail_id($right_pid));

            if ($left_post_image_att && $right_post_image_att) {
                $left_post_image_basename = $this->add_image_requirement($left_post_image_att['url']);
                $left_post_image_source = $this->apply_the_text_filter($left_post_image_att['credit_to']);
                $left_post_image_caption = $this->apply_the_text_filter($left_post_image_att['caption']);
                $right_post_image_basename = $this->add_image_requirement($right_post_image_att['url']);
                $right_post_image_source = $this->apply_the_text_filter($right_post_image_att['credit_to']);
                $right_post_image_caption = $this->apply_the_text_filter($right_post_image_att['caption']);
            } else {
                $left_post_image_basename = '';
                $left_post_image_source = '';
                $left_post_image_caption = '';
                $right_post_image_basename = '';
                $right_post_image_source = '';
                $right_post_image_caption = '';
            }

            $template .= "\\sidebysidetitles{{$left_post_title}}{{$right_post_title}}{{$this->get_varname_for_post_index($index)}}{{$this->get_varname_for_post_index($index + 1)}}
\\sidebysidenews{{$left_post_image_basename}}{{$right_post_image_basename}}{{$left_post_content}}{{$right_post_content}}{{$left_post_image_source}}{{$right_post_image_source}}{{$left_post_image_caption}}{{$right_post_image_caption}}
";
        }


        if (count($this->transient_ads) > 0) {
            $template .= '
\noindent\includegraphics[width=\textwidth]{' . $this->add_image_requirement(rposul_retrieve_adv_image_url($this->transient_ads[0])) . '}';
        }
        
        return $this->apply_the_tex_template_filter($template, $page_number);
    }

}
