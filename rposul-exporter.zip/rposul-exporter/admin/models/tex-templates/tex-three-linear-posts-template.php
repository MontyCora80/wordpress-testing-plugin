<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class TexThreeLinearPostsTemplate extends TexBaseTemplate {

    private $generate_filter_counter = 1;
    const MAX_POSTS = 3;
    const MIN_POST_CONTENT_LENGTH = 3600;
    const MAX_POST_CONTENT_LENGTH = 4500;

    public function can_add_post($post_id) {
        $postlen = rposul_retrieve_post_content_length($post_id);
        return count($this->post_ids) < self::MAX_POSTS && $postlen > self::MIN_POST_CONTENT_LENGTH && $postlen < self::MAX_POST_CONTENT_LENGTH;
    }
    
    public function is_export_ready() {
        return count($this->post_ids) == self::MAX_POSTS;
    }

    private function doOneSelection($ar_info) {
        $ar_info_count = count($ar_info);
        for ($i = 0; $i < $ar_info_count - 2; $i ++) {
            $j = $i + 1; // Start right after i.
            $k = $ar_info_count - 1; // Start at the end of the array.
            while ($k >= $j) {
                // We got a match! All done.
                $value_sum = $ar_info[$i]["length"] + $ar_info[$j]["length"] + $ar_info[$k]["length"];
                if ($value_sum > self::MIN_POST_CONTENT_LENGTH && $value_sum < self::MAX_POST_CONTENT_LENGTH) {
                    return array($i, $j, $k);
                }

                $value_sum ? $k-- : $j++;
            }
        }
        // found nothing
        return null;
    }

    /*     * *
     * This function will modify the entry array by removing from it the 
     * consumed posts
     */

    public function consume(&$ar_postids) {
        $ar_info = array();
        foreach ($ar_postids as $index => $post_obj) {
            $postlen = $post_obj->post_content_length;
            if ($postlen > 700) {
                $ar_info[] = array("index" => $index,
                    "pid" => $post_obj->ID,
                    "length" => $postlen);
            }
        }
        $retValues = $this->doOneSelection($ar_info);
        if (isset($retValues)) {
            foreach ($retValues as $val) {
                unset($ar_postids[$ar_info[$val]['index']]);
            }
            $returnPids = array();
            foreach ($retValues as $val) {
                $returnPids[] = $ar_info[$val]['pid'];
            }
            $this->post_ids = $returnPids;
            return $returnPids;
        } else {
            $this->post_ids = array();
            return null;
        }
    }

    protected function generate($page_number) {
        $this->generate_filter_counter = 1;

        $title = array();
        $template = "";
        $postcounter = 0;

        foreach ($this->post_ids as $pid) {
            $content_post = get_post($pid);
            $title = mb_strtoupper(rposul_ensure_ends_with_dot($content_post->post_title));
            $content = $this->apply_the_content_filter($content_post);
            $template .= '\titleone{' . $this->apply_the_text_filter($title) . '}
                
\vspace*{-.1cm}	
\begin{multicols}{4}
' . $content . '
\end{multicols}
';
            if (++$postcounter != 3) {
                $template .= '\linebit{0.4pt}' . "\n";
            }
        }

        return $this->apply_the_tex_template_filter($template, $page_number);
    }

    function apply_the_content_filter($wp_post) {

        $filebasename = $this->add_image_requirement(wp_get_attachment_url(get_post_thumbnail_id($wp_post->ID)));       

        $image_before = $this->generate_filter_counter % 2 ? false : true;

        if ($image_before) {
            $filteredContent = '%pampa_remove_' . $this->generate_filter_counter . "\n";
            $filteredContent .= '\par\medskip\noindent\minipage{\linewidth}\includegraphics[width=\linewidth]{' . $filebasename . '}\endminipage\par\medskip' . "\n";
            $filteredContent .= '%endpampa_remove_' . $this->generate_filter_counter . "\n";
            $filteredContent .= parent::apply_the_content_filter($wp_post);
        }

        if (!$image_before) {
            $filteredContent = parent::apply_the_content_filter($wp_post);
            $filteredContent .= "\n" . '%pampa_remove_' . $this->generate_filter_counter . "\n";
            $filteredContent .= '\par\medskip\noindent\minipage{\linewidth}\includegraphics[width=\linewidth]{' . $filebasename . '}\endminipage\par\medskip' . "\n";
            $filteredContent .= '%endpampa_remove_' . $this->generate_filter_counter . "\n";
        }
        $this->generate_filter_counter++;
        return $filteredContent;
    }

}
