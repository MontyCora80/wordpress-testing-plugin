<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class TexTwoPostsTemplate extends TexBaseTemplate {

    protected $INCREASE_IMAGE_SIZE_THRESHOLD;
    protected $IMAGE_ADJUSTMENT_THRESHOLD;

    public function __construct($post_ids, $advertisement_ids, $extra_values) {
        parent::__construct($post_ids, $advertisement_ids, $extra_values);
        $this->limit_post_count = 2;
        $this->IMAGE_ADJUSTMENT_THRESHOLD = 1600; // threshold to allow max 2 column image
        $this->limit_post_min_length = 1000;
        $this->limit_post_max_length = 2200;
        $this->limit_page_min_length = 2000;
        $this->limit_page_max_length = 4200;
        $this->INCREASE_IMAGE_SIZE_THRESHOLD = 200;
        
    }

    protected function get_image_column_width($image_att, $postlen) {
        /* if ($image_att['aspect_ratio'] < 0.6) {
          $image_column_width = 1;
          } else if ($image_att['aspect_ratio'] < 0.8) {
          $image_column_width = 2;
          //} else if ($image_att['aspect_ratio'] < 1.9) {
          //                $image_column_width = 3;
          } else {
          //              $image_column_width = 4;
          $image_column_width = 3;
          } */

        //TODO corrigir isso apos termos suporte funcionando para imagem de todas as colunas
        if ($image_att['aspect_ratio'] < 0.6) {
            $image_column_width = 1;
        } else if ($image_att['aspect_ratio'] < 1.8) {
            $image_column_width = 2;
        } else {
            $image_column_width = 3;
        }

        # compensating with the image for text which are too far from goal.
        #if ($postlen > $this->MAX_POST_CONTENT_LENGTH - $this->INCREASE_IMAGE_SIZE_THRESHOLD && $image_column_width > 1) {
        #    $image_column_width--;
        #} else if ($postlen < $this->MIN_POST_CONTENT_LENGTH + $this->INCREASE_IMAGE_SIZE_THRESHOLD && $image_column_width < 3) {
        #    $image_column_width++;
        #}
        return $image_column_width;
    }

    public function get_varname_for_post_index($index, $prefix = "", $suffix = "") {
        return $prefix . chr(65 + $index) . $suffix;
    }

    protected function get_document_class() {
        return '\documentclass{osultwonews}';
    }

    protected function get_preamble() {
        $preamble = '
\usepackage{xstring}';

        $image_threshold_reached = false;
        if (count($this->transient_ads) > 0) {
            $preamble .= '
\newsavebox{\advertisementbox}
\savebox{\advertisementbox}{\includegraphics[width=\textwidth]{' . $this->add_image_requirement(rposul_retrieve_adv_image_url($this->transient_ads[0])) . '}}
\instantiateadvertisementbottomframe{\advertisementbox}';
        }

        for ($index = count($this->post_ids) - 1; $index >= 0; $index--) {
            $pid = $this->post_ids[$index];
            $post_obj = get_post($pid);
            $post_content_length = rposul_retrieve_post_content_length($pid);
            if ($index == 0 || count($this->transient_ads) == 0) {
                $image_att = rposul_get_attachment(get_post_thumbnail_id($pid));
                if ($image_att) {
                    $image_column_width = $this->get_image_column_width($image_att, $post_content_length);
                } else {
                    $image_column_width = 0;
                }
                
                if ($post_content_length >= $this->IMAGE_ADJUSTMENT_THRESHOLD) {
                    $image_threshold_reached = true;
                    if ($image_column_width > 2) {
                        $image_column_width = 2;
                    }
                }

                if ($image_column_width < 4 && ($index % 2 == 0)) {
                    $image_position_left_shift = 1;
                } else {
                    $image_position_left_shift = 0;
                }
            } else {
                $image_column_width = 0;
                $image_position_left_shift = 0;
            }

            $titlebox_varname = '\\' . $this->get_varname_for_post_index($index, 'title', 'box');
            $title_top_spacing = $index == 0 ? '' : '\vspace{3mm}';
            $preamble .= '
\newsavebox{' . $titlebox_varname . '}%
\savebox{' . $titlebox_varname . '}{\begin{minipage}{\textwidth}%
' . $title_top_spacing . '%
\hugetitle[' . $this->get_varname_for_post_index($index) . ']{' . $this->apply_the_text_filter(rposul_ensure_ends_with_dot($post_obj->post_title)) . '}%
\end{minipage}}
\instantiatestackedframe{' . $image_column_width . '}{' . $this->apply_the_content_filter($post_obj) . '}{' . $this->get_varname_for_post_index($index) . '}{' . $titlebox_varname . '}{' . ($index == 0 ? '' : 'y') . '}{' . $image_position_left_shift . '}';
        }
        
        $imagelengthcorrection = $image_threshold_reached ? '\setlength{\imageheight}{\imageheight - 0.04\textheight}' : '';
        
        
        return $imagelengthcorrection . $preamble;
    }

    /*     * *
     * This function will modify the entry array by removing from it the 
     * consumed posts
     */

    protected function doOneSelection($ar_info) {
        $ar_info_count = count($ar_info);
        for ($i = 0; $i < $ar_info_count - 1; $i ++) {
            for ($j = $i + 1; $j < $ar_info_count; $j++) {
                $value_sum = $ar_info[$i]["length"] + $ar_info[$j]["length"];
                if ($value_sum > $this->limit_page_min_length && $value_sum < $this->limit_page_max_length) {
                    return array($i, $j);
                }
            }
        }
        // found nothing
        return null;
    }

    public function consume(&$ar_postids) {
        $ar_info = array();
        foreach ($ar_postids as $index => $post_obj) {
            $postlen = rposul_retrieve_post_content_length($post_obj->ID);
            if ($postlen > $this->limit_post_min_length && $postlen < $this->limit_post_max_length) {
                $ar_info[] = array(
                    "index" => $index,
                    "pid" => $post_obj->ID,
                    "length" => $postlen);
            }
        }
        $retValues = $this->doOneSelection($ar_info);
        if (isset($retValues)) {
            foreach ($retValues as $val) {
                unset($ar_postids[$ar_info[$val]['index']]);
            }
            $returnPids = array();
            foreach ($retValues as $val) {
                $returnPids[] = $ar_info[$val]['pid'];
            }
            $this->post_ids = $returnPids;
            return $returnPids;
        } else {
            $this->post_ids = array();
            return null;
        }
    }

    protected function generate($page_number) {
        $template = "";

        if (count($this->transient_ads) > 0) {
            $template .= '
\begin{staticcontents*}{advertisementframe}
\usebox{\advertisementbox}
\end{staticcontents*}';
        }

        for ($index = count($this->post_ids) - 1; $index >= 0; $index--) {
            $pid = $this->post_ids[$index];
            $content_post = get_post($pid);
            $content = $this->apply_the_content_filter($content_post);
            $image_att = rposul_get_attachment(get_post_thumbnail_id($pid));
            if ($image_att) {
                $imagename = $this->add_image_requirement($image_att['url']);
                $sourcename = $this->apply_the_text_filter($image_att['credit_to']);
                $caption = $this->apply_the_text_filter($image_att['caption']);
            }

            if ($index != 0) {
                $template .= '
\begin{staticcontents*}{' . $this->get_varname_for_post_index($index, "line") . '}
\linebit{0.4pt}
\end{staticcontents*}';
            }

            $template .= '
\begin{staticcontents*}{' . $this->get_varname_for_post_index($index, "title") . '}
\usebox{\\' . $this->get_varname_for_post_index($index, "title", 'box') . '}
\end{staticcontents*}
';

            if ($index == 0 || count($this->transient_ads) == 0) {
                if ($image_att) {
                    $template .= '
\begin{staticcontents*}{' . $this->get_varname_for_post_index($index, "picture") . '}
\ClipImage{\\' . $this->get_varname_for_post_index($index, "picture", 'width') . '}{\\' . $this->get_varname_for_post_index($index, "picture", 'height') . '}{' . $imagename . '}{' . $sourcename . '}{' . $caption . '}
\end{staticcontents*}

';
                }
            }

            $template .= $content;

            if ($index != 0) {
                $template .= '\skipflowframes{' . $this->get_varname_for_post_index($index) . '}';
            } else {
                $template .= '\checkflowframe{' . $this->get_varname_for_post_index($index) . '}';
            }
        }

        return $this->apply_the_tex_template_filter($template, $page_number);
    }

}
