<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
define('COLUMN_LENGTH_LIMIT', 1350);

class TexSmallPostsTemplate extends TexBaseTemplate {

    public function __construct($post_ids, $advertisement_ids, $extra_values) {
        parent::__construct($post_ids, $advertisement_ids, $extra_values);
        $this->limit_post_count = 0;
        $this->limit_post_min_length = 10;
        $this->limit_post_max_length = 650;
    }

    /**
     * Export is not blocked by this function, is only an indicator if everything is ready
     * @return type
     */
    public function is_export_ready() {
        $errors = new WP_Error();
        
        $returnData = $this->separate_columns();
        if ($returnData[1]) {
            $errors->add('error', 'Posts insuficientes para popular todas as colunas.');
        }
        
        return rposul_wp_error_merge(parent::is_export_ready(), $errors);
    }

    private function calculate_considered_post_size($pid) {
        $post = get_post($pid);
        $posttitlelen = mb_strlen(rposul_ensure_ends_with_dot($post->post_title));
        $postlen = rposul_retrieve_post_content_length($pid);
        return 1.25 * $posttitlelen + $postlen;
    }
    
    
    protected function get_document_class() {
        return '\documentclass{osulnoticiaspequenas}';
    }

    protected function get_preamble() {
        return '\namedsmallnewsborder{' . arr_get($this->extra_values, 'title', '') . '}';
    }

    public function consume(&$ar_postids) {
        $ar_info = array();
        $returnPids = array();

        $remainingColumns = 3;
        do {
            $accPostLen = 0;
            foreach ($ar_postids as $index => $post_obj) {
                $consideredlength = $this->calculate_considered_post_size($post_obj->ID);
                if ($consideredlength <= $this->limit_post_max_length && array_search($post_obj->ID, $returnPids) === false) {
                    $returnPids[] = $post_obj->ID;
                    $ar_info[] = array("index" => $index,
                        "pid" => $post_obj->ID,
                        "length" => $consideredlength);
                    $accPostLen += $consideredlength;
                }

                #TODO if we passed by a lot the limit then we search for a small post to 
                #remove, if we dont have a small post to remove we count how many posts are added
                # if there are only a few "2" for example we remove the larger post
                # if there are a lot "5" for example we remove two smaller posts
                # this is an idea only
                if ($accPostLen > COLUMN_LENGTH_LIMIT) {
                    break;
                }
            }

            if ($accPostLen < COLUMN_LENGTH_LIMIT) {
                # we could not complete the page so we giveup everything
                $this->post_ids = array();
                return null;
            }

            $remainingColumns --;
        } while ($remainingColumns != 0);

        if (count($ar_info) > 0) {
            foreach ($ar_info as $val) {
                unset($ar_postids[$val['index']]);
            }
            $this->post_ids = $returnPids;
            return $returnPids;
        } else {
            $this->post_ids = array();
            return null;
        }
    }

    private function separate_columns() {
        $columns_posts = array();
        $columns_posts[] = array();
        $column_size_counter = 0;
        foreach ($this->post_ids as $pid) {
            $consideredlength = $this->calculate_considered_post_size($pid);
            $columns_posts[count($columns_posts) - 1][] = $pid;
            $column_size_counter += $consideredlength;
            if ($column_size_counter > COLUMN_LENGTH_LIMIT && count($columns_posts) < 3) {
                $columns_posts[] = array();
                $column_size_counter = 0;
            }
        }
        $can_still_add_posts = count($columns_posts) < 3 || $column_size_counter < COLUMN_LENGTH_LIMIT;
        return array($columns_posts, $can_still_add_posts);
    }

    protected function generate($page_number) {
        $returnData = $this->separate_columns();
        $columns_posts = $returnData[0];

        $template = '
\vspace{-10pt}
\begin{multicols}{3}
';

        $has_ads = count($this->transient_ads) > 0;
        if ($has_ads) {
            $ad_obj = $this->transient_ads[0];
            $placement = $ad_obj->relative_placement;
            /* @var $ad_obj Rposul_advertisement */
            $template .= '\newlength{\adv' . $placement . 'length}
\newsavebox{\adv' . $placement . 'box}
\savebox{\adv' . $placement . 'box}{\includegraphics[width=\textwidth]{' . $this->add_image_requirement(rposul_retrieve_adv_image_url($ad_obj)) . '}}
\settototalheight{\adv' . $placement . 'length}{\usebox{\adv' . $placement . 'box}}
';
        }

        for ($i = 0; $i < count($columns_posts); $i++) {
            $column = $columns_posts[$i];
            $ad_size = $has_ads ? '\adv' . $placement . 'length' : '0pt';
            $template .= '\begin{smallnewscolumn}{' . $ad_size . '}';
            foreach ($column as $pid) {
                $post_obj = get_post($pid);
                $template .= '
\smallnews{' . $this->apply_the_text_filter(rposul_ensure_ends_with_dot($post_obj->post_title)) . '}'
                        . '{ ' . $this->apply_the_text_filter($post_obj->post_content) . '}
';
            }
            $template .= '\end{smallnewscolumn}';

            if ($has_ads && $i == 0) {
                $template .= "\n\n" . '\noindent\usebox{\adv' . $placement . 'box}' . "\n\n";
            }
        }

        $template .= '\end{multicols}';

        return $this->apply_the_tex_template_filter($template, $page_number);
    }

    protected function apply_the_text_filter($the_mod_content) {
        # remove line breaks because this is compacted text
        $filteredContent = parent::apply_the_text_filter($the_mod_content);
        $filteredContent = preg_replace("/\r|\n/", "", $filteredContent);
        // Put spaces after dots that had /r/n removed
        // This is the dumb way
        $filteredContent = preg_replace('/\.(\w)/', '. $1', $filteredContent);
        return $filteredContent;
    }

}
